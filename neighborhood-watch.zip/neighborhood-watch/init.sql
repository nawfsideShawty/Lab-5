CREATE DATABASE IF NOT EXISTS neighborhood_watch;
CREATE DATABASE IF NOT EXISTS keycloak;

USE neighborhood_watch;

-- Users table (extended by Keycloak)
CREATE TABLE IF NOT EXISTS user_profiles (
    id VARCHAR(36) PRIMARY KEY,
    keycloak_id VARCHAR(255) UNIQUE NOT NULL,
    email VARCHAR(255) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    phone_number VARCHAR(20),
    user_type ENUM('ADMIN', 'SECURITY_OFFICER', 'MEMBER') NOT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_approved BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE
);

-- Houses table
CREATE TABLE IF NOT EXISTS houses (
    id VARCHAR(36) PRIMARY KEY,
    address VARCHAR(255) NOT NULL,
    qr_code VARCHAR(255) UNIQUE NOT NULL,
    owner_name VARCHAR(255),
    owner_contact VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Patrol scans table
CREATE TABLE IF NOT EXISTS patrol_scans (
    id VARCHAR(36) PRIMARY KEY,
    officer_id VARCHAR(36) NOT NULL,
    house_id VARCHAR(36) NOT NULL,
    scan_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    comments TEXT,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    FOREIGN KEY (officer_id) REFERENCES user_profiles(id),
    FOREIGN KEY (house_id) REFERENCES houses(id)
);

-- Community posts table
CREATE TABLE IF NOT EXISTS community_posts (
    id VARCHAR(36) PRIMARY KEY,
    member_id VARCHAR(36) NOT NULL,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    post_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_emergency BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (member_id) REFERENCES user_profiles(id)
);

-- Post comments table
CREATE TABLE IF NOT EXISTS post_comments (
    id VARCHAR(36) PRIMARY KEY,
    post_id VARCHAR(36) NOT NULL,
    member_id VARCHAR(36) NOT NULL,
    comment TEXT NOT NULL,
    comment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES community_posts(id),
    FOREIGN KEY (member_id) REFERENCES user_profiles(id)
);

-- Subscriptions table
CREATE TABLE IF NOT EXISTS subscriptions (
    id VARCHAR(36) PRIMARY KEY,
    member_id VARCHAR(36) NOT NULL,
    start_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    end_date TIMESTAMP,
    amount DECIMAL(10, 2),
    status ENUM('ACTIVE', 'SUSPENDED', 'CANCELLED') DEFAULT 'ACTIVE',
    payment_reference VARCHAR(255),
    FOREIGN KEY (member_id) REFERENCES user_profiles(id)
);

-- Patrol schedules table
CREATE TABLE IF NOT EXISTS patrol_schedules (
    id VARCHAR(36) PRIMARY KEY,
    officer_id VARCHAR(36) NOT NULL,
    scheduled_date DATE NOT NULL,
    expected_scans INT DEFAULT 0,
    completed_scans INT DEFAULT 0,
    FOREIGN KEY (officer_id) REFERENCES user_profiles(id)
);

-- Payments table
CREATE TABLE IF NOT EXISTS payments (
    id VARCHAR(36) PRIMARY KEY,
    member_id VARCHAR(36) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    payment_method ENUM('MOBILE_CARD', 'BANK_TRANSFER', 'CREDIT_CARD') NOT NULL,
    transaction_id VARCHAR(255) UNIQUE,
    status ENUM('PENDING', 'COMPLETED', 'FAILED') DEFAULT 'PENDING',
    payment_gateway_response TEXT,
    FOREIGN KEY (member_id) REFERENCES user_profiles(id)
);

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('SMS', 'EMAIL', 'APP') NOT NULL,
    sent_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('SENT', 'PENDING', 'FAILED') DEFAULT 'PENDING',
    FOREIGN KEY (user_id) REFERENCES user_profiles(id)
);

-- Patrol violations table
CREATE TABLE IF NOT EXISTS patrol_violations (
    id VARCHAR(36) PRIMARY KEY,
    officer_id VARCHAR(36) NOT NULL,
    violation_date DATE NOT NULL,
    expected_scans INT NOT NULL,
    actual_scans INT NOT NULL,
    compliance_rate DECIMAL(5, 2) NOT NULL,
    status ENUM('PENDING', 'UNDER_REVIEW', 'RESOLVED') DEFAULT 'PENDING',
    resolved_by VARCHAR(36),
    resolution_notes TEXT,
    FOREIGN KEY (officer_id) REFERENCES user_profiles(id),
    FOREIGN KEY (resolved_by) REFERENCES user_profiles(id)
);

-- Reports table
CREATE TABLE IF NOT EXISTS reports (
    id VARCHAR(36) PRIMARY KEY,
    report_type ENUM('WEEKLY', 'MONTHLY', 'YEARLY') NOT NULL,
    report_date DATE NOT NULL,
    generated_by VARCHAR(36) NOT NULL,
    data JSON,
    file_path VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (generated_by) REFERENCES user_profiles(id)
);

-- Emergency alerts table
CREATE TABLE IF NOT EXISTS emergency_alerts (
    id VARCHAR(36) PRIMARY KEY,
    member_id VARCHAR(36) NOT NULL,
    alert_type ENUM('SECURITY', 'MEDICAL', 'FIRE', 'OTHER') NOT NULL,
    location VARCHAR(255),
    description TEXT NOT NULL,
    status ENUM('ACTIVE', 'RESOLVED') DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP,
    resolved_by VARCHAR(36),
    FOREIGN KEY (member_id) REFERENCES user_profiles(id),
    FOREIGN KEY (resolved_by) REFERENCES user_profiles(id)
);