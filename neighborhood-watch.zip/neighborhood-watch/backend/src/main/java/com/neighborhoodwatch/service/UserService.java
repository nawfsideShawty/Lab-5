package com.neighborhoodwatch.service;

import com.neighborhoodwatch.entity.UserProfile;
import com.neighborhoodwatch.model.UserSyncRequest;
import com.neighborhoodwatch.model.UserType;
import com.neighborhoodwatch.controller.AdminController;
import com.neighborhoodwatch.repository.UserProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    
    @Autowired
    private UserProfileRepository userProfileRepository;
    
    public UserProfile getUserById(String userId) {
        return userProfileRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found with id: " + userId));
    }
    
    // ADD THIS MISSING METHOD
    public UserProfile getUserByUsername(String username) {
        return userProfileRepository.findByUsername(username)
            .orElseThrow(() -> new RuntimeException("User not found with username: " + username));
    }
    
    // ADD THIS METHOD FOR OPTIONAL FIND
    public Optional<UserProfile> findByUsername(String username) {
        return userProfileRepository.findByUsername(username);
    }
    
    public List<UserProfile> getActiveSecurityOfficers() {
        return userProfileRepository.findByUserTypeAndIsActiveTrue(UserType.SECURITY_OFFICER);
    }
    
    public List<UserProfile> getActiveMembers() {
        return userProfileRepository.findByUserTypeAndIsActiveTrue(UserType.MEMBER);
    }
    
    public List<UserProfile> getAdmins() {
        return userProfileRepository.findByUserTypeAndIsActiveTrue(UserType.ADMIN);
    }
    
    public List<UserProfile> getSecurityOfficers() {
        return userProfileRepository.findByUserType(UserType.SECURITY_OFFICER);
    }
    
    public UserProfile createUser(AdminController.CreateUserRequest request) {
        UserProfile user = new UserProfile();
        user.setId(java.util.UUID.randomUUID().toString());
        user.setEmail(request.getEmail());
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setPhoneNumber(request.getPhoneNumber());
        user.setUserType(UserType.valueOf(request.getUserType()));
        user.setIsApproved(false);
        user.setIsActive(true);
        user.setRegistrationDate(java.time.LocalDateTime.now());
        
        return userProfileRepository.save(user);
    }
    
    public UserProfile approveUser(String userId) {
        UserProfile user = getUserById(userId);
        user.setIsApproved(true);
        return userProfileRepository.save(user);
    }
    
    public List<UserProfile> getAllUsers() {
        return userProfileRepository.findAll();
    }
    
    public void suspendOfficer(String officerId) {
        UserProfile officer = getUserById(officerId);
        officer.setIsActive(false);
        userProfileRepository.save(officer);
    }
    
    public void reinstateOfficer(String officerId) {
        UserProfile officer = getUserById(officerId);
        officer.setIsActive(true);
        userProfileRepository.save(officer);
    }
    
    public void activateSubscription(String memberId) {
        UserProfile member = getUserById(memberId);
        // Implementation for subscription activation
        // This could update subscription status, expiry date, etc.
        userProfileRepository.save(member);
    }
    
    public Long countActiveOfficers() {
        return userProfileRepository.countByUserTypeAndIsActiveTrue(UserType.SECURITY_OFFICER);
    }
    
    public Long countActiveSubscriptions() {
        // Count users with active subscriptions
        // For now, return count of active residents
        return userProfileRepository.countByUserTypeAndIsActiveTrue(UserType.MEMBER);
    }
    
    // ADD THIS METHOD FOR KEYCLOAK SYNC
    @Transactional
    public UserProfile syncUserWithKeycloak(UserSyncRequest syncRequest) {
        // Check if user already exists by keycloakId
        Optional<UserProfile> existingUser = userProfileRepository.findByKeycloakId(syncRequest.getKeycloakId());
        
        if (existingUser.isPresent()) {
            // User exists, update if needed
            UserProfile user = existingUser.get();
            boolean updated = false;
            
            // Update email if changed
            if (syncRequest.getEmail() != null && !syncRequest.getEmail().equals(user.getEmail())) {
                user.setEmail(syncRequest.getEmail());
                updated = true;
            }
            
            // Update names if changed
            if (syncRequest.getFirstName() != null && !syncRequest.getFirstName().equals(user.getFirstName())) {
                user.setFirstName(syncRequest.getFirstName());
                updated = true;
            }
            
            if (syncRequest.getLastName() != null && !syncRequest.getLastName().equals(user.getLastName())) {
                user.setLastName(syncRequest.getLastName());
                updated = true;
            }
            
            if (updated) {
                user = userProfileRepository.save(user);
            }
            
            return user;
        } else {
            // New user - create profile
            UserProfile newUser = new UserProfile();
            newUser.setId(java.util.UUID.randomUUID().toString());
            newUser.setKeycloakId(syncRequest.getKeycloakId());
            newUser.setEmail(syncRequest.getEmail());
            newUser.setFirstName(syncRequest.getFirstName());
            newUser.setLastName(syncRequest.getLastName());
            newUser.setUserType(UserType.MEMBER); // Default to MEMBER, admin can change later
            newUser.setIsApproved(true); // Auto-approve Keycloak users
            newUser.setIsActive(true);
            newUser.setRegistrationDate(java.time.LocalDateTime.now());
            
            // Set phone number if available from username (optional)
            if (syncRequest.getUsername() != null && syncRequest.getUsername().matches("\\d+")) {
                newUser.setPhoneNumber(syncRequest.getUsername());
            }
            
            return userProfileRepository.save(newUser);
        }
    }
    
    // ADD THIS HELPER METHOD
    public Optional<UserProfile> findByKeycloakId(String keycloakId) {
        return userProfileRepository.findByKeycloakId(keycloakId);
    }
}