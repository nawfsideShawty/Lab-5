package com.neighborhoodwatch.entity;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "houses")
public class House {
    @Id
    private String id;
    
    private String address;
    private String qrCode;
    private String ownerName;
    private String ownerContact;
    private Boolean isActive = true;
    
    // Additional fields for better management
    private String gpsCoordinates;
    private String neighborhoodZone;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    // Constructors
    public House() {}
    
    public House(String id, String address, String ownerName, String ownerContact) {
        this.id = id;
        this.address = address;
        this.ownerName = ownerName;
        this.ownerContact = ownerContact;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public String getQrCode() { return qrCode; }
    public void setQrCode(String qrCode) { this.qrCode = qrCode; }
    
    public String getOwnerName() { return ownerName; }
    public void setOwnerName(String ownerName) { this.ownerName = ownerName; }
    
    public String getOwnerContact() { return ownerContact; }
    public void setOwnerContact(String ownerContact) { this.ownerContact = ownerContact; }
    
    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }
    
    public String getGpsCoordinates() { return gpsCoordinates; }
    public void setGpsCoordinates(String gpsCoordinates) { this.gpsCoordinates = gpsCoordinates; }
    
    public String getNeighborhoodZone() { return neighborhoodZone; }
    public void setNeighborhoodZone(String neighborhoodZone) { this.neighborhoodZone = neighborhoodZone; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}