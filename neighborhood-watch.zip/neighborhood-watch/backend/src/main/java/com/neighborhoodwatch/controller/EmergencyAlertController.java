// EmergencyAlertController.java
package com.neighborhoodwatch.controller;

import com.neighborhoodwatch.entity.EmergencyAlert;
import com.neighborhoodwatch.model.EmergencyAlertRequest;
import com.neighborhoodwatch.service.EmergencyAlertService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/emergency")
@CrossOrigin(origins = "http://localhost:3000")
public class EmergencyAlertController {

    @Autowired
    private EmergencyAlertService emergencyAlertService;

    @PostMapping("/alert")
    public ResponseEntity<EmergencyAlert> raiseAlert(
            @AuthenticationPrincipal String memberId,
            @RequestBody EmergencyAlertRequest request) {
        try {
            EmergencyAlert alert = emergencyAlertService.raiseEmergencyAlert(memberId, request);
            return ResponseEntity.ok(alert);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/alerts")
    public ResponseEntity<List<EmergencyAlert>> getActiveAlerts() {
        try {
            List<EmergencyAlert> alerts = emergencyAlertService.getActiveAlerts();
            return ResponseEntity.ok(alerts);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/alert/{alertId}/resolve")
    public ResponseEntity<EmergencyAlert> resolveAlert(
            @PathVariable String alertId,
            @RequestParam String resolvedBy) {
        try {
            EmergencyAlert alert = emergencyAlertService.resolveAlert(alertId, resolvedBy);
            return ResponseEntity.ok(alert);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
}