package com.neighborhoodwatch.model;

public enum PaymentMethod {
    CARD, BANK_TRANSFER, MOBILE_MONEY
}