// PatrolStats.java
package com.neighborhoodwatch.model;

public class PatrolStats {
    private Long weeklyScans;
    private Double complianceRate;
    private Long activeAlerts;
    private Double coverageRate;
    
    // Getters and setters
    public Long getWeeklyScans() { return weeklyScans; }
    public void setWeeklyScans(Long weeklyScans) { this.weeklyScans = weeklyScans; }
    
    public Double getComplianceRate() { return complianceRate; }
    public void setComplianceRate(Double complianceRate) { this.complianceRate = complianceRate; }
    
    public Long getActiveAlerts() { return activeAlerts; }
    public void setActiveAlerts(Long activeAlerts) { this.activeAlerts = activeAlerts; }
    
    public Double getCoverageRate() { return coverageRate; }
    public void setCoverageRate(Double coverageRate) { this.coverageRate = coverageRate; }
}