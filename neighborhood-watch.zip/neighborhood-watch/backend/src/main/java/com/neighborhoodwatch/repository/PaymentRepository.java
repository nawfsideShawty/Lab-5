package com.neighborhoodwatch.repository;

import com.neighborhoodwatch.entity.Payment;
import com.neighborhoodwatch.model.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, String> {
    List<Payment> findByMemberIdOrderByPaymentDateDesc(String memberId);
    Optional<Payment> findByTransactionId(String transactionId);
    
    @Query("SELECT COALESCE(SUM(p.amount), 0) FROM Payment p WHERE p.status = :status AND p.paymentDate BETWEEN :startDate AND :endDate")
    Double sumCompletedPaymentsBetweenDates(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate, @Param("status") PaymentStatus status);
    
    default Double sumCompletedPaymentsBetweenDates(LocalDate startDate, LocalDate endDate) {
        return sumCompletedPaymentsBetweenDates(startDate, endDate, PaymentStatus.COMPLETED);
    }
}