package com.neighborhoodwatch.controller;

import com.neighborhoodwatch.entity.House;
import com.neighborhoodwatch.service.HouseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/houses")
public class HouseController {
    
    @Autowired
    private HouseService houseService;
    
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<House> createHouse(@RequestBody House house) {
        return ResponseEntity.ok(houseService.createHouse(house));
    }
    
    @GetMapping
    public ResponseEntity<List<House>> getAllHouses() {
        return ResponseEntity.ok(houseService.getAllActiveHouses());
    }
}