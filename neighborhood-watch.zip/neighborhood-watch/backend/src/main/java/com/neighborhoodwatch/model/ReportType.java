package com.neighborhoodwatch.model;

public enum ReportType {
    WEEKLY, MONTHLY, YEARLY
}