package com.neighborhoodwatch.service;

import com.neighborhoodwatch.entity.Report;
import com.neighborhoodwatch.model.ReportType;
import com.neighborhoodwatch.repository.PatrolScanRepository;
import com.neighborhoodwatch.repository.PaymentRepository;
import com.neighborhoodwatch.repository.ReportRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class ReportService {
    
    @Autowired
    private PatrolScanRepository patrolScanRepository;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private PaymentRepository paymentRepository;
    
    @Autowired
    private ReportRepository reportRepository;
    
    public Report generateWeeklyReport(String adminId) {
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusDays(7);
        
        Map<String, Object> reportData = generateReportData(startDate, endDate);
        return saveReport(ReportType.WEEKLY, startDate, endDate, adminId, reportData);
    }
    
    public Report generateMonthlyReport(String adminId) {
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusMonths(1);
        
        Map<String, Object> reportData = generateReportData(startDate, endDate);
        return saveReport(ReportType.MONTHLY, startDate, endDate, adminId, reportData);
    }
    
    public Report generateYearlyReport(String adminId) {
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusYears(1);
        
        Map<String, Object> reportData = generateReportData(startDate, endDate);
        return saveReport(ReportType.YEARLY, startDate, endDate, adminId, reportData);
    }
    
    private Map<String, Object> generateReportData(LocalDate startDate, LocalDate endDate) {
        Map<String, Object> data = new HashMap<>();
        
        data.put("totalScans", patrolScanRepository.countScansBetweenDates(startDate, endDate));
        data.put("activeOfficers", userService.countActiveOfficers());
        data.put("complianceRate", calculateOverallComplianceRate(startDate, endDate));
        
        data.put("totalRevenue", paymentRepository.sumCompletedPaymentsBetweenDates(startDate, endDate));
        data.put("activeSubscriptions", userService.countActiveSubscriptions());
        
        data.put("patrolViolations", patrolScanRepository.countViolationsBetweenDates(startDate, endDate));
        data.put("resolvedViolations", patrolScanRepository.countResolvedViolationsBetweenDates(startDate, endDate));
        
        data.put("emergencyAlerts", patrolScanRepository.countEmergencyAlertsBetweenDates(startDate, endDate));
        data.put("communityPosts", patrolScanRepository.countCommunityPostsBetweenDates(startDate, endDate));
        
        return data;
    }
    
    private double calculateOverallComplianceRate(LocalDate startDate, LocalDate endDate) {
        // Implementation needed - calculate actual compliance rate
        return 95.0;
    }
    
    private Report saveReport(ReportType type, LocalDate startDate, LocalDate endDate, 
                            String adminId, Map<String, Object> data) {
        Report report = new Report();
        report.setId(UUID.randomUUID().toString());
        report.setReportType(type);
        report.setReportDate(LocalDate.now());
        report.setGeneratedBy(adminId);
        
        try {
            ObjectMapper mapper = new ObjectMapper();
            report.setData(mapper.writeValueAsString(data));
        } catch (Exception e) {
            throw new RuntimeException("Error serializing report data", e);
        }
        
        return reportRepository.save(report);
    }
    
    public byte[] generateReportPdf(String reportId) {
        Report report = reportRepository.findById(reportId)
            .orElseThrow(() -> new RuntimeException("Report not found"));
        
        return generatePdfFromReportData(report);
    }
    
    private byte[] generatePdfFromReportData(Report report) {
        // PDF generation implementation needed
        return new byte[0];
    }
}