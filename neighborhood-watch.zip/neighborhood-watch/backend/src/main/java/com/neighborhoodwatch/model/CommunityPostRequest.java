package com.neighborhoodwatch.model;

public class CommunityPostRequest {
    private String title;
    private String content;
    private String parentPostId; // null for new posts, postId for replies
    private String category;
    
    // Getters and setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    
    public String getParentPostId() { return parentPostId; }
    public void setParentPostId(String parentPostId) { this.parentPostId = parentPostId; }
    
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
}