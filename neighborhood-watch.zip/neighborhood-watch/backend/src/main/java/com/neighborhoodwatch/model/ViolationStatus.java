package com.neighborhoodwatch.model;

public enum ViolationStatus {
    PENDING, RESOLVED, DISMISSED
}