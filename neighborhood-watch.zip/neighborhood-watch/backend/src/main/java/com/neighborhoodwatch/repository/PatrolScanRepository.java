package com.neighborhoodwatch.repository;

import com.neighborhoodwatch.entity.PatrolScan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface PatrolScanRepository extends JpaRepository<PatrolScan, String> {

    List<PatrolScan> findByOfficerIdOrderByScanTimeDesc(String officerId);
    List<PatrolScan> findByScanTimeAfterOrderByScanTimeDesc(LocalDateTime scanTime);
    
    @Query("SELECT COUNT(ps) FROM PatrolScan ps WHERE ps.officer.id = :officerId AND DATE(ps.scanTime) = :date")
    int countScansByOfficerAndDate(@Param("officerId") String officerId, @Param("date") LocalDate date);

    @Query("SELECT COUNT(DISTINCT ps.house.id) FROM PatrolScan ps WHERE DATE(ps.scanTime) = :date")
    Long countDistinctHousesScannedToday(@Param("date") LocalDate date);
    
    @Query("SELECT COUNT(ps) FROM PatrolScan ps WHERE ps.scanTime BETWEEN :startDate AND :endDate")
    Long countScansBetweenDates(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);
    
    default Long countScansBetweenDates(LocalDate startDate, LocalDate endDate) {
        return countScansBetweenDates(startDate.atStartOfDay(), endDate.plusDays(1).atStartOfDay());
    }
    
    @Query("SELECT COUNT(*) FROM PatrolViolation pv WHERE pv.violationDate BETWEEN :startDate AND :endDate")
    Long countViolationsBetweenDates(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
    
    @Query("SELECT COUNT(*) FROM PatrolViolation pv WHERE pv.status = 'RESOLVED' AND pv.violationDate BETWEEN :startDate AND :endDate")
    Long countResolvedViolationsBetweenDates(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
    
    @Query("SELECT COUNT(*) FROM EmergencyAlert ea WHERE ea.createdAt BETWEEN :startDate AND :endDate")
    Long countEmergencyAlertsBetweenDates(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
    
    @Query("SELECT COUNT(*) FROM CommunityPost cp WHERE cp.createdAt BETWEEN :startDate AND :endDate")
    Long countCommunityPostsBetweenDates(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
}