package com.neighborhoodwatch.controller;

import com.neighborhoodwatch.model.CommunityPost;
import com.neighborhoodwatch.model.CommunityPostRequest;
import com.neighborhoodwatch.service.CommunityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/community")
@CrossOrigin(origins = "http://localhost:3000")
public class CommunityController {

    @Autowired
    private CommunityService communityService;

    @GetMapping("/posts")
    public ResponseEntity<List<CommunityPost>> getAllPosts(@RequestParam(required = false) String category) {
        try {
            List<CommunityPost> posts;
            if (category != null && !category.isEmpty() && !category.equals("all")) {
                posts = communityService.getPostsByCategory(category);
            } else {
                posts = communityService.getAllPosts();
            }
            return ResponseEntity.ok(posts);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PostMapping("/posts")
    public ResponseEntity<CommunityPost> createPost(
            @AuthenticationPrincipal String memberId,
            @RequestBody CommunityPostRequest request) {
        try {
            CommunityPost post = communityService.createPost(memberId, request);
            return ResponseEntity.ok(post);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PostMapping("/posts/{postId}/like")
    public ResponseEntity<CommunityPost> likePost(@PathVariable String postId) {
        try {
            CommunityPost post = communityService.likePost(postId);
            return ResponseEntity.ok(post);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/posts/{postId}/pin")
    public ResponseEntity<CommunityPost> pinPost(
            @PathVariable String postId,
            @RequestParam boolean pinned) {
        try {
            CommunityPost post = communityService.pinPost(postId, pinned);
            return ResponseEntity.ok(post);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
}