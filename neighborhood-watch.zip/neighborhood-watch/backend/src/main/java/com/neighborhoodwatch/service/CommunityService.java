package com.neighborhoodwatch.service;

import com.neighborhoodwatch.model.CommunityPost;
import com.neighborhoodwatch.model.CommunityPostRequest;
import com.neighborhoodwatch.repository.CommunityPostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.UUID;

@Service
public class CommunityService {
    
    @Autowired
    private CommunityPostRepository communityPostRepository;
    
    @Autowired
    private UserService userService;
    
    public CommunityPost createPost(String memberId, CommunityPostRequest request) {
        CommunityPost post = new CommunityPost();
        post.setId(UUID.randomUUID().toString());
        post.setMemberId(memberId);
        post.setTitle(request.getTitle());
        post.setContent(request.getContent());
        post.setParentPostId(request.getParentPostId());
        post.setCategory(request.getCategory() != null ? request.getCategory() : "general");
        
        return communityPostRepository.save(post);
    }
    
    public List<CommunityPost> getAllPosts() {
        List<CommunityPost> mainPosts = communityPostRepository.findByParentPostIdIsNullOrderByCreatedAtDesc();
        
        // Load replies for each main post
        for (CommunityPost post : mainPosts) {
            List<CommunityPost> replies = communityPostRepository.findByParentPostIdOrderByCreatedAtAsc(post.getId());
            post.setReplies(replies);
        }
        
        return mainPosts;
    }
    
    public List<CommunityPost> getPostsByCategory(String category) {
        List<CommunityPost> mainPosts = communityPostRepository.findByCategoryAndParentPostIdIsNullOrderByCreatedAtDesc(category);
        
        // Load replies for each main post
        for (CommunityPost post : mainPosts) {
            List<CommunityPost> replies = communityPostRepository.findByParentPostIdOrderByCreatedAtAsc(post.getId());
            post.setReplies(replies);
        }
        
        return mainPosts;
    }
    
    public CommunityPost likePost(String postId) {
        CommunityPost post = communityPostRepository.findById(postId)
            .orElseThrow(() -> new RuntimeException("Post not found"));
        
        post.setLikeCount(post.getLikeCount() + 1);
        return communityPostRepository.save(post);
    }
    
    public CommunityPost pinPost(String postId, boolean pinned) {
        CommunityPost post = communityPostRepository.findById(postId)
            .orElseThrow(() -> new RuntimeException("Post not found"));
        
        post.setIsPinned(pinned);
        return communityPostRepository.save(post);
    }
}