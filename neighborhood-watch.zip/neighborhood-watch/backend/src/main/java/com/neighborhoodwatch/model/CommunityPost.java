package com.neighborhoodwatch.model;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "community_posts")
public class CommunityPost {
    @Id
    private String id;
    
    private String memberId;
    private String title;
    private String content;
    private LocalDateTime createdAt;
    
    // New fields for forum functionality
    private String parentPostId; // null for original posts, contains id for replies
    private String category; // "general", "safety", "events", etc.
    private int likeCount = 0;
    private boolean isPinned = false;
    
    // Transient field for frontend (not stored in DB)
    @Transient
    private List<CommunityPost> replies = new ArrayList<>();
    
    // Constructors
    public CommunityPost() {}
    
    public CommunityPost(String id, String memberId, String title, String content, 
                        String parentPostId, String category) {
        this.id = id;
        this.memberId = memberId;
        this.title = title;
        this.content = content;
        this.parentPostId = parentPostId;
        this.category = category;
        this.createdAt = LocalDateTime.now();
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getMemberId() { return memberId; }
    public void setMemberId(String memberId) { this.memberId = memberId; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public String getParentPostId() { return parentPostId; }
    public void setParentPostId(String parentPostId) { this.parentPostId = parentPostId; }
    
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    
    public int getLikeCount() { return likeCount; }
    public void setLikeCount(int likeCount) { this.likeCount = likeCount; }
    
    public boolean getIsPinned() { return isPinned; }
    public void setIsPinned(boolean isPinned) { this.isPinned = isPinned; }
    
    public List<CommunityPost> getReplies() { return replies; }
    public void setReplies(List<CommunityPost> replies) { this.replies = replies; }
    
    // Helper methods
    public boolean isMainPost() {
        return parentPostId == null;
    }
    
    public boolean isReply() {
        return parentPostId != null;
    }
}