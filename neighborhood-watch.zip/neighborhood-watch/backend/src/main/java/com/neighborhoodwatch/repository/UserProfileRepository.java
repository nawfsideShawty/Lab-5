package com.neighborhoodwatch.repository;

import com.neighborhoodwatch.entity.UserProfile;
import com.neighborhoodwatch.model.UserType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserProfileRepository extends JpaRepository<UserProfile, String> {
    
    List<UserProfile> findByUserType(UserType userType);
    
    List<UserProfile> findByUserTypeAndIsActiveTrue(UserType userType);
    
    Long countByUserTypeAndIsActiveTrue(UserType userType);
    
    List<UserProfile> findByIsActiveTrue();
    
    Long countByIsActiveTrue();
    
    // ADD THIS METHOD FOR KEYCLOAK SYNC
    Optional<UserProfile> findByKeycloakId(String keycloakId);
    
    // ADD THIS MISSING METHOD FOR USERNAME LOOKUP
    Optional<UserProfile> findByUsername(String username);
}