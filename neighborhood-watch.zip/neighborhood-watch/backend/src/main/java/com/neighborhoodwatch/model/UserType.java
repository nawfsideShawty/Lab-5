package com.neighborhoodwatch.model;

public enum UserType {
    ADMIN, SECURITY_OFFICER, MEMBER
}