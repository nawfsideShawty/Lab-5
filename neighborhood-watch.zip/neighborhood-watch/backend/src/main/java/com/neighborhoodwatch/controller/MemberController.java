package com.neighborhoodwatch.controller;

import com.neighborhoodwatch.entity.House;
import com.neighborhoodwatch.entity.UserProfile;
import com.neighborhoodwatch.service.HouseService;
import com.neighborhoodwatch.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/member")
@PreAuthorize("hasRole('MEMBER')")
public class MemberController {
    
    @Autowired
    private HouseService houseService;
    
    @Autowired
    private UserService userService;

    @GetMapping("/qr-code")
    public ResponseEntity<Map<String, String>> getMemberQRCode(Authentication authentication) {
        try {
            String username = authentication.getName();
            UserProfile member = userService.getUserByUsername(username);
            
            if (member == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Member not found"));
            }
            
            // Get member's house
            Optional<House> memberHouse = houseService.getHouseByMember(member.getId());
            if (memberHouse.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "No house found for member"));
            }
            
            House house = memberHouse.get();
            
            // Create QR code content
            String qrContent = String.format(
                "NEIGHBORHOOD_WATCH|HOUSE:%s|MEMBER:%s|TIMESTAMP:%d",
                house.getId(),
                member.getId(),
                System.currentTimeMillis()
            );
            
            Map<String, String> response = new HashMap<>();
            response.put("qrContent", qrContent);
            response.put("houseId", house.getId());
            response.put("address", house.getAddress());
            response.put("generatedAt", Instant.now().toString());
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Could not generate QR code: " + e.getMessage()));
        }
    }
}