// src/main/java/com/neighborhoodwatch/controller/AuthController.java
package com.neighborhoodwatch.controller;

import com.neighborhoodwatch.entity.UserProfile;
import com.neighborhoodwatch.model.UserSyncRequest;
import com.neighborhoodwatch.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {

    @Autowired
    private UserService userService;

    @PostMapping("/sync-user")
    public ResponseEntity<Map<String, Object>> syncUser(@RequestBody UserSyncRequest syncRequest) {
        try {
            System.out.println("Syncing user with Keycloak ID: " + syncRequest.getKeycloakId());
            
            UserProfile userProfile = userService.syncUserWithKeycloak(syncRequest);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("isNewUser", userProfile.getRegistrationDate().isAfter(java.time.LocalDateTime.now().minusMinutes(1)));
            response.put("user", Map.of(
                "id", userProfile.getId(),
                "email", userProfile.getEmail(),
                "firstName", userProfile.getFirstName(),
                "lastName", userProfile.getLastName(),
                "userType", userProfile.getUserType().name(),
                "isApproved", userProfile.getIsApproved()
            ));
            
            System.out.println("User sync successful: " + userProfile.getEmail());
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            System.err.println("User sync failed: " + e.getMessage());
            e.printStackTrace();
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("error", "Failed to sync user: " + e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    // Optional: Health check endpoint
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "Authentication Service");
        return ResponseEntity.ok(response);
    }
}