package com.neighborhoodwatch.service;

import com.neighborhoodwatch.entity.EmergencyAlert;
import com.neighborhoodwatch.model.EmergencyAlertRequest;
import com.neighborhoodwatch.entity.AlertStatus;
import com.neighborhoodwatch.entity.UserProfile;
import com.neighborhoodwatch.repository.EmergencyAlertRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class EmergencyAlertService {
    
    @Autowired
    private EmergencyAlertRepository emergencyAlertRepository;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private SmsService smsService;
    
    @Autowired
    private EmailService emailService;
    
    public EmergencyAlert raiseEmergencyAlert(String memberId, EmergencyAlertRequest request) {
        EmergencyAlert alert = new EmergencyAlert();
        alert.setId(UUID.randomUUID().toString());
        alert.setMemberId(memberId);
        alert.setAlertType(request.getAlertType());
        alert.setLocation(request.getLocation());
        alert.setDescription(request.getDescription());
        alert.setStatus(AlertStatus.ACTIVE);
        alert.setCreatedAt(LocalDateTime.now());
        
        EmergencyAlert savedAlert = emergencyAlertRepository.save(alert);
        
        // Notify security officers and members
        notifyEmergencyStakeholders(savedAlert);
        
        return savedAlert;
    }
    
    private void notifyEmergencyStakeholders(EmergencyAlert alert) {
        UserProfile member = userService.getUserById(alert.getMemberId());
        
        // Notify security officers
        List<UserProfile> officers = userService.getActiveSecurityOfficers();
        for (UserProfile officer : officers) {
            smsService.sendEmergencyAlertToOfficer(officer.getPhoneNumber(), alert, member);
            // Also send app notification
        }
        
        // Notify other members
        List<UserProfile> members = userService.getActiveMembers();
        for (UserProfile neighborhoodMember : members) {
            if (!neighborhoodMember.getId().equals(member.getId())) {
                smsService.sendEmergencyAlertToMember(neighborhoodMember.getPhoneNumber(), alert);
            }
        }
        
        // Notify administrators
        List<UserProfile> admins = userService.getAdmins();
        for (UserProfile admin : admins) {
            emailService.sendEmergencyAlertToAdmin(admin.getEmail(), alert, member);
        }
    }
    
    public EmergencyAlert resolveAlert(String alertId, String resolvedBy) {
        EmergencyAlert alert = emergencyAlertRepository.findById(alertId)
            .orElseThrow(() -> new RuntimeException("Alert not found"));
        
        alert.setStatus(AlertStatus.RESOLVED);
        alert.setResolvedBy(resolvedBy);
        alert.setResolvedAt(LocalDateTime.now());
        
        return emergencyAlertRepository.save(alert);
    }
    
    public List<EmergencyAlert> getActiveAlerts() {
        return emergencyAlertRepository.findByStatusOrderByCreatedAtDesc(AlertStatus.ACTIVE);
    }
}