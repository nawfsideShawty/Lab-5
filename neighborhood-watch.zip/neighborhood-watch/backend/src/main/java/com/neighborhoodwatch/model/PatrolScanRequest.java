// PatrolScanRequest.java
package com.neighborhoodwatch.model;

public class PatrolScanRequest {
    private String houseId;
    private String comments;
    private Double latitude;
    private Double longitude;
    
    // Getters and setters
    public String getHouseId() { return houseId; }
    public void setHouseId(String houseId) { this.houseId = houseId; }
    
    public String getComments() { return comments; }
    public void setComments(String comments) { this.comments = comments; }
    
    public Double getLatitude() { return latitude; }
    public void setLatitude(Double latitude) { this.latitude = latitude; }
    
    public Double getLongitude() { return longitude; }
    public void setLongitude(Double longitude) { this.longitude = longitude; }
}