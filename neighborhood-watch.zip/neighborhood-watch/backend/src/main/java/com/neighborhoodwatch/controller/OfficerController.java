package com.neighborhoodwatch.controller;

import com.neighborhoodwatch.entity.PatrolScan;
import com.neighborhoodwatch.model.PatrolScanRequest;
import com.neighborhoodwatch.service.PatrolMonitorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/officer")
@PreAuthorize("hasRole('SECURITY_OFFICER')")
public class OfficerController {
    
    @Autowired
    private PatrolMonitorService patrolMonitorService;
    
    @PostMapping("/scan")
    public ResponseEntity<?> recordScan(@RequestBody Map<String, Object> scanRequest, Authentication authentication) {
        try {
            String officerId = authentication.getName();
            String qrContent = (String) scanRequest.get("qrContent");
            
            // Create PatrolScanRequest from QR content
            PatrolScanRequest request = new PatrolScanRequest();
            request.setHouseId(extractHouseIdFromQR(qrContent));
            request.setComments("QR Code Scan");
            request.setLatitude((Double) scanRequest.get("latitude"));
            request.setLongitude((Double) scanRequest.get("longitude"));
            
            PatrolScan scan = patrolMonitorService.recordScan(officerId, request);
            return ResponseEntity.ok(scan);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Scan recording failed: " + e.getMessage());
        }
    }
    
    private String extractHouseIdFromQR(String qrContent) {
        try {
            String[] parts = qrContent.split("\\|");
            for (String part : parts) {
                if (part.startsWith("HOUSE:")) {
                    return part.substring(6);
                }
            }
            throw new RuntimeException("Invalid QR code format");
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse QR code: " + e.getMessage());
        }
    }
}