package com.neighborhoodwatch.entity;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "patrol_scans")
public class PatrolScan {
    @Id
    private String id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "officer_id")
    private UserProfile officer;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "house_id")
    private House house;
    
    private LocalDateTime scanTime;
    private String comments;
    private Double latitude;
    private Double longitude;
    
    // Constructors
    public PatrolScan() {}
    
    public PatrolScan(String id, UserProfile officer, House house, LocalDateTime scanTime) {
        this.id = id;
        this.officer = officer;
        this.house = house;
        this.scanTime = scanTime;
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public UserProfile getOfficer() { return officer; }
    public void setOfficer(UserProfile officer) { this.officer = officer; }
    
    public House getHouse() { return house; }
    public void setHouse(House house) { this.house = house; }
    
    public LocalDateTime getScanTime() { return scanTime; }
    public void setScanTime(LocalDateTime scanTime) { this.scanTime = scanTime; }
    
    public String getComments() { return comments; }
    public void setComments(String comments) { this.comments = comments; }
    
    public Double getLatitude() { return latitude; }
    public void setLatitude(Double latitude) { this.latitude = latitude; }
    
    public Double getLongitude() { return longitude; }
    public void setLongitude(Double longitude) { this.longitude = longitude; }
}