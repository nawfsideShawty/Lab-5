package com.neighborhoodwatch.service;

import com.neighborhoodwatch.entity.House;
import com.neighborhoodwatch.entity.PatrolScan;
import com.neighborhoodwatch.entity.PatrolViolation;
import com.neighborhoodwatch.entity.UserProfile;
import com.neighborhoodwatch.model.PatrolScanRequest;
import com.neighborhoodwatch.model.PatrolStats;
import com.neighborhoodwatch.model.ViolationStatus;
import com.neighborhoodwatch.repository.HouseRepository;
import com.neighborhoodwatch.repository.PatrolScanRepository;
import com.neighborhoodwatch.repository.PatrolViolationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class PatrolMonitorService {
    
    @Value("${patrol.compliance-threshold:80.0}")
    private Double complianceThreshold;
    
    @Autowired
    private PatrolScanRepository patrolScanRepository;
    
    @Autowired
    private HouseRepository houseRepository;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private PatrolViolationRepository patrolViolationRepository;
    
    @Autowired
    private EmailService emailService;
    
    @Autowired
    private SmsService smsService;

    // Missing method: Record a patrol scan
    public PatrolScan recordScan(String officerId, PatrolScanRequest request) {
        UserProfile officer = userService.getUserById(officerId);
        House house = getHouseById(request.getHouseId());
        
        if (house == null) {
            throw new RuntimeException("House not found with ID: " + request.getHouseId());
        }
        
        if (!house.getIsActive()) {
            throw new RuntimeException("House is not active for scanning");
        }
        
        PatrolScan scan = new PatrolScan();
        scan.setId(UUID.randomUUID().toString());
        scan.setOfficer(officer);
        scan.setHouse(house);
        scan.setScanTime(LocalDateTime.now());
        scan.setComments(request.getComments());
        scan.setLatitude(request.getLatitude());
        scan.setLongitude(request.getLongitude());
        
        return patrolScanRepository.save(scan);
    }

    // Missing method: Get officer's scans
    public List<PatrolScan> getOfficerScans(String officerId) {
        return patrolScanRepository.findByOfficerIdOrderByScanTimeDesc(officerId);
    }

    // Missing method: Get patrol statistics
    public PatrolStats getPatrolStats() {
        LocalDate today = LocalDate.now();
        LocalDate weekStart = today.minusDays(7);
        
        PatrolStats stats = new PatrolStats();
        
        // Calculate weekly scans
        Long weeklyScans = patrolScanRepository.countScansBetweenDates(weekStart, today);
        stats.setWeeklyScans(weeklyScans != null ? weeklyScans : 0L);
        
        // Calculate compliance rate (simplified - in real app, calculate based on expected vs actual)
        double complianceRate = calculateOverallComplianceRate();
        stats.setComplianceRate(complianceRate);
        
        // Count active alerts (you'll need to implement this in EmergencyAlertRepository)
        // Long activeAlerts = emergencyAlertRepository.countByStatus(AlertStatus.ACTIVE);
        stats.setActiveAlerts(0L); // Temporary - replace with actual count
        
        // Calculate coverage rate (simplified)
        double coverageRate = calculateCoverageRate();
        stats.setCoverageRate(coverageRate);
        
        return stats;
    }

    // Missing method: Get recent scans for statistics
    public List<PatrolScan> getRecentScans() {
        LocalDateTime last24Hours = LocalDateTime.now().minusHours(24);
        return patrolScanRepository.findByScanTimeAfterOrderByScanTimeDesc(last24Hours);
    }

    // Missing method: Get patrol violations
    public List<PatrolViolation> getPatrolViolations() {
        return patrolViolationRepository.findAll();
    }

    // Missing method: Get house by ID
    private House getHouseById(String houseId) {
        return houseRepository.findById(houseId)
            .orElseThrow(() -> new RuntimeException("House not found with ID: " + houseId));
    }

    // Missing method: Calculate overall compliance rate
    private double calculateOverallComplianceRate() {
        // Simplified calculation - in real app, calculate based on expected vs actual scans per officer
        LocalDate today = LocalDate.now();
        LocalDate weekStart = today.minusDays(7);
        
        Long totalScans = patrolScanRepository.countScansBetweenDates(weekStart, today);
        List<UserProfile> officers = userService.getSecurityOfficers();
        
        if (officers.isEmpty() || totalScans == 0) {
            return 0.0;
        }
        
        // Assume each officer should scan 10 houses per day (7 days = 70 scans per officer)
        int expectedScansPerOfficer = 70;
        int totalExpectedScans = officers.size() * expectedScansPerOfficer;
        
        double complianceRate = (double) totalScans / totalExpectedScans * 100;
        return Math.min(complianceRate, 100.0); // Cap at 100%
    }

    // Missing method: Calculate coverage rate
    private double calculateCoverageRate() {
        // Simplified calculation - in real app, calculate based on houses covered vs total houses
        Long totalHouses = houseRepository.countByIsActiveTrue();
        LocalDate today = LocalDate.now();
        
        if (totalHouses == 0) {
            return 0.0;
        }
        
        // Count unique houses scanned today
        Long housesScannedToday = patrolScanRepository.countDistinctHousesScannedToday(today);
        
        double coverageRate = (double) housesScannedToday / totalHouses * 100;
        return Math.min(coverageRate, 100.0); // Cap at 100%
    }

    // Missing method: Get officer's assigned houses (implementation needed)
    private List<House> getOfficerAssignedHouses(String officerId) {
        // Implementation needed - return houses assigned to this officer
        // For now, return all active houses as a fallback
        return houseRepository.findByIsActiveTrue();
    }

    // Existing scheduled method (keep this)
    @Scheduled(cron = "0 0 23 * * ?")
    public void checkDailyPatrolCompliance() {
        LocalDate today = LocalDate.now();
        List<UserProfile> officers = userService.getSecurityOfficers();
        
        for (UserProfile officer : officers) {
            checkOfficerCompliance(officer, today);
        }
    }
    
    private void checkOfficerCompliance(UserProfile officer, LocalDate date) {
        List<House> assignedHouses = getOfficerAssignedHouses(officer.getId());
        int expectedScans = assignedHouses.size();
        int actualScans = patrolScanRepository.countScansByOfficerAndDate(officer.getId(), date);
        
        if (expectedScans == 0) return; // No houses assigned
        
        double complianceRate = (double) actualScans / expectedScans * 100;
        
        if (complianceRate < complianceThreshold) {
            handleComplianceViolation(officer, date, expectedScans, actualScans, complianceRate);
        }
    }
    
    private void handleComplianceViolation(UserProfile officer, LocalDate date, 
                                         int expectedScans, int actualScans, double complianceRate) {
        PatrolViolation violation = new PatrolViolation();
        violation.setId(UUID.randomUUID().toString());
        violation.setOfficerId(officer.getId());
        violation.setViolationDate(date);
        violation.setExpectedScans(expectedScans);
        violation.setActualScans(actualScans);
        violation.setComplianceRate(complianceRate);
        violation.setStatus(ViolationStatus.PENDING);
        patrolViolationRepository.save(violation);
        
        userService.suspendOfficer(officer.getId());
        
        notifyViolationStakeholders(officer, violation);
    }
    
    private void notifyViolationStakeholders(UserProfile officer, PatrolViolation violation) {
        List<UserProfile> admins = userService.getAdmins();
        for (UserProfile admin : admins) {
            emailService.sendPatrolViolationAlertToAdmin(admin.getEmail(), officer, violation);
            smsService.sendPatrolViolationAlertToAdmin(admin.getPhoneNumber(), officer, violation);
        }
        
        List<UserProfile> members = userService.getActiveMembers();
        for (UserProfile member : members) {
            smsService.sendPatrolViolationAlertToMember(member.getPhoneNumber(), officer, violation);
        }
    }
    
    public void resolveViolation(String violationId, String adminId, String resolutionNotes) {
        PatrolViolation violation = patrolViolationRepository.findById(violationId)
            .orElseThrow(() -> new RuntimeException("Violation not found"));
        
        violation.setStatus(ViolationStatus.RESOLVED);
        violation.setResolvedBy(adminId);
        violation.setResolutionNotes(resolutionNotes);
        violation.setResolvedAt(LocalDateTime.now());
        patrolViolationRepository.save(violation);
        
        if (resolutionNotes.toLowerCase().contains("qr code") || 
            resolutionNotes.toLowerCase().contains("technical")) {
            userService.reinstateOfficer(violation.getOfficerId());
        }
    }
}