package com.neighborhoodwatch.service;

import com.neighborhoodwatch.entity.House;
import com.neighborhoodwatch.repository.HouseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class HouseService {
    
    @Autowired
    private HouseRepository houseRepository;
    
    public House createHouse(House house) {
        // Implementation needed
        if (house.getId() == null) {
            house.setId(java.util.UUID.randomUUID().toString());
        }
        return houseRepository.save(house);
    }
    
    public List<House> getAllActiveHouses() {
        return houseRepository.findByIsActiveTrue();
    }
    
    public Optional<House> getHouseByMember(String memberId) {
        // Implementation to find house by member ID
        // This depends on your data model relationship between members and houses
        // For now, return the first active house (you'll need to implement proper relationship)
        List<House> activeHouses = houseRepository.findByIsActiveTrue();
        return activeHouses.stream().findFirst();
    }
}