package com.neighborhoodwatch.entity;

public enum AlertStatus {
    ACTIVE, RESOLVED, CANCELLED
}