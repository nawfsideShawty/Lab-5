// PatrolScanController.java
package com.neighborhoodwatch.controller;

import com.neighborhoodwatch.entity.PatrolScan;
import com.neighborhoodwatch.model.PatrolScanRequest;
import com.neighborhoodwatch.model.PatrolStats;
import com.neighborhoodwatch.service.PatrolMonitorService;
import com.neighborhoodwatch.entity.PatrolViolation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/patrol")
@CrossOrigin(origins = "http://localhost:3000")
public class PatrolScanController {

    @Autowired
    private PatrolMonitorService patrolMonitorService;

    @PostMapping("/scan")
    public ResponseEntity<PatrolScan> recordScan(
            @AuthenticationPrincipal String officerId,
            @RequestBody PatrolScanRequest request) {
        try {
            PatrolScan scan = patrolMonitorService.recordScan(officerId, request);
            return ResponseEntity.ok(scan);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/my-scans")
    public ResponseEntity<List<PatrolScan>> getMyScans(@AuthenticationPrincipal String officerId) {
        try {
            List<PatrolScan> scans = patrolMonitorService.getOfficerScans(officerId);
            return ResponseEntity.ok(scans);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/stats")
    public ResponseEntity<PatrolStats> getStats() {
        try {
            PatrolStats stats = patrolMonitorService.getPatrolStats();
            return ResponseEntity.ok(stats);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/recent-scans")
    public ResponseEntity<List<PatrolScan>> getRecentScans() {
        try {
            // Implementation for recent scans across all officers
            return ResponseEntity.ok(List.of());
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/violations")
    public ResponseEntity<List<PatrolViolation>> getViolations() {
        try {
            // Implementation for violations
            return ResponseEntity.ok(List.of());
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
}