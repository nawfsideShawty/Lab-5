package com.neighborhoodwatch.model;

public enum PaymentStatus {
    PENDING, COMPLETED, FAILED, CANCELLED
}