package com.neighborhoodwatch.entity;

import com.neighborhoodwatch.model.ViolationStatus;
import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "patrol_violations")
public class PatrolViolation {
    @Id
    private String id;
    
    private String officerId;
    private LocalDate violationDate;
    private int expectedScans;
    private int actualScans;
    private double complianceRate;
    
    @Enumerated(EnumType.STRING)
    private ViolationStatus status;
    
    private String resolvedBy;
    private String resolutionNotes;
    private LocalDateTime createdAt;
    private LocalDateTime resolvedAt;
    
    // Constructors
    public PatrolViolation() {}
    
    public PatrolViolation(String id, String officerId, LocalDate violationDate, int expectedScans, int actualScans) {
        this.id = id;
        this.officerId = officerId;
        this.violationDate = violationDate;
        this.expectedScans = expectedScans;
        this.actualScans = actualScans;
        this.complianceRate = (double) actualScans / expectedScans * 100;
        this.status = ViolationStatus.PENDING;
        this.createdAt = LocalDateTime.now();
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getOfficerId() { return officerId; }
    public void setOfficerId(String officerId) { this.officerId = officerId; }
    
    public LocalDate getViolationDate() { return violationDate; }
    public void setViolationDate(LocalDate violationDate) { this.violationDate = violationDate; }
    
    public int getExpectedScans() { return expectedScans; }
    public void setExpectedScans(int expectedScans) { this.expectedScans = expectedScans; }
    
    public int getActualScans() { return actualScans; }
    public void setActualScans(int actualScans) { this.actualScans = actualScans; }
    
    public double getComplianceRate() { return complianceRate; }
    public void setComplianceRate(double complianceRate) { this.complianceRate = complianceRate; }
    
    public ViolationStatus getStatus() { return status; }
    public void setStatus(ViolationStatus status) { this.status = status; }
    
    public String getResolvedBy() { return resolvedBy; }
    public void setResolvedBy(String resolvedBy) { this.resolvedBy = resolvedBy; }
    
    public String getResolutionNotes() { return resolutionNotes; }
    public void setResolutionNotes(String resolutionNotes) { this.resolutionNotes = resolutionNotes; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getResolvedAt() { return resolvedAt; }
    public void setResolvedAt(LocalDateTime resolvedAt) { this.resolvedAt = resolvedAt; }
}