package com.neighborhoodwatch.service;

import com.neighborhoodwatch.entity.Payment;
import com.neighborhoodwatch.entity.UserProfile;
import com.neighborhoodwatch.model.PaymentMethod;
import com.neighborhoodwatch.model.PaymentStatus;  
import com.neighborhoodwatch.repository.PaymentRepository;
import com.stripe.Stripe;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class PaymentService {
    
    @Value("${stripe.secret-key:sk_test_dummy_key}")
    private String stripeSecretKey;
    
    @Value("${subscription.monthly-fee:50.00}")
    private Double monthlyFee;
    
    @Autowired
    private PaymentRepository paymentRepository;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private EmailService emailService;
    
    @Autowired
    private SmsService smsService;
    
    public PaymentIntent createPaymentIntent(String userId, String paymentMethod) {
        Stripe.apiKey = stripeSecretKey;
        
        try {
            // Only process real payments if we have real Stripe key
            if (stripeSecretKey.startsWith("sk_test_dummy")) {
                System.out.println("💰 [DUMMY PAYMENT] Processing dummy payment for user: " + userId);
                
                // Create dummy payment record
                Payment payment = new Payment();
                payment.setId(UUID.randomUUID().toString());
                payment.setMemberId(userId);
                payment.setAmount(monthlyFee);
                payment.setPaymentMethod(PaymentMethod.valueOf(paymentMethod));
                payment.setTransactionId("dummy_txn_" + UUID.randomUUID().toString());
                payment.setStatus(PaymentStatus.COMPLETED);
                payment.setPaymentDate(java.time.LocalDateTime.now());
                paymentRepository.save(payment);
                
                // Activate subscription
                userService.activateSubscription(userId);
                
                // Send dummy confirmations
                UserProfile user = userService.getUserById(userId);
                if (user != null) {
                    System.out.println("✅ [DUMMY] Payment confirmed for: " + user.getEmail());
                    if (user.getPhoneNumber() != null) {
                        smsService.sendPaymentConfirmation(user.getPhoneNumber(), monthlyFee);
                    }
                }
                
                return null; // Return null for dummy payments
            }
            
            // Real Stripe payment processing
            Map<String, Object> params = new HashMap<>();
            params.put("amount", (int) (monthlyFee * 100)); // Convert to cents
            params.put("currency", "bwp");
            params.put("payment_method_types", List.of("card"));
            params.put("metadata", Map.of("user_id", userId, "payment_method", paymentMethod));
            
            PaymentIntent intent = PaymentIntent.create(params);
            
            // Save payment record
            Payment payment = new Payment();
            payment.setId(UUID.randomUUID().toString());
            payment.setMemberId(userId);
            payment.setAmount(monthlyFee);
            payment.setPaymentMethod(PaymentMethod.valueOf(paymentMethod));
            payment.setTransactionId(intent.getId());
            payment.setStatus(PaymentStatus.PENDING);
            payment.setPaymentDate(java.time.LocalDateTime.now());
            paymentRepository.save(payment);
            
            return intent;
        } catch (Exception e) {
            throw new RuntimeException("Payment processing failed", e);
        }
    }
    
    public void handlePaymentSuccess(String transactionId) {
        Payment payment = paymentRepository.findByTransactionId(transactionId)
            .orElseThrow(() -> new RuntimeException("Payment not found"));
        
        payment.setStatus(PaymentStatus.COMPLETED);
        paymentRepository.save(payment);
        
        // Update user subscription
        userService.activateSubscription(payment.getMemberId());
        
        // Send confirmation
        UserProfile user = userService.getUserById(payment.getMemberId());
        emailService.sendPaymentConfirmation(user.getEmail(), payment.getAmount());
        smsService.sendPaymentConfirmation(user.getPhoneNumber(), payment.getAmount());
    }
    
    public List<Payment> getUserPaymentHistory(String userId) {
        return paymentRepository.findByMemberIdOrderByPaymentDateDesc(userId);
    }
}