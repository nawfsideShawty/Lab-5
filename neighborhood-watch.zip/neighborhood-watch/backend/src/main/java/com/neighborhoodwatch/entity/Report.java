package com.neighborhoodwatch.entity;

import com.neighborhoodwatch.model.ReportType;
import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "reports")
public class Report {
    @Id
    private String id;
    
    @Enumerated(EnumType.STRING)
    private ReportType reportType;
    
    private LocalDate reportDate;
    private String generatedBy;
    
    @Column(columnDefinition = "TEXT")
    private String data;
    
    private LocalDate periodStart;
    private LocalDate periodEnd;
    
    // Constructors
    public Report() {}
    
    public Report(String id, ReportType reportType, String generatedBy, LocalDate periodStart, LocalDate periodEnd) {
        this.id = id;
        this.reportType = reportType;
        this.generatedBy = generatedBy;
        this.periodStart = periodStart;
        this.periodEnd = periodEnd;
        this.reportDate = LocalDate.now();
    }
    
    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public ReportType getReportType() { return reportType; }
    public void setReportType(ReportType reportType) { this.reportType = reportType; }
    
    public LocalDate getReportDate() { return reportDate; }
    public void setReportDate(LocalDate reportDate) { this.reportDate = reportDate; }
    
    public String getGeneratedBy() { return generatedBy; }
    public void setGeneratedBy(String generatedBy) { this.generatedBy = generatedBy; }
    
    public String getData() { return data; }
    public void setData(String data) { this.data = data; }
    
    public LocalDate getPeriodStart() { return periodStart; }
    public void setPeriodStart(LocalDate periodStart) { this.periodStart = periodStart; }
    
    public LocalDate getPeriodEnd() { return periodEnd; }
    public void setPeriodEnd(LocalDate periodEnd) { this.periodEnd = periodEnd; }
}