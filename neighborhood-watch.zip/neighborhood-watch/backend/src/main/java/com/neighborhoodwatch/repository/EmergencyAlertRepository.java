package com.neighborhoodwatch.repository;

import com.neighborhoodwatch.entity.EmergencyAlert;
import com.neighborhoodwatch.entity.AlertStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface EmergencyAlertRepository extends JpaRepository<EmergencyAlert, String> {
    Long countByStatus(AlertStatus status);
    List<EmergencyAlert> findByStatusOrderByCreatedAtDesc(AlertStatus status);
}