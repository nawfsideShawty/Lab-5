package com.neighborhoodwatch.service;

import com.neighborhoodwatch.entity.EmergencyAlert;
import com.neighborhoodwatch.entity.PatrolViolation;
import com.neighborhoodwatch.entity.UserProfile;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class SmsService {
    
    @Value("${twilio.account-sid:AC_dummy_sid}")
    private String accountSid;
    
    @Value("${twilio.auth-token:dummy_token}")
    private String authToken;
    
    @Value("${twilio.phone-number:+15551234567}")
    private String twilioPhoneNumber;
    
    public void sendSms(String to, String message) {
        try {
            // Only initialize Twilio if we have real credentials
            if (!accountSid.startsWith("AC_dummy")) {
                Twilio.init(accountSid, authToken);
                
                Message.creator(
                    new PhoneNumber(to),
                    new PhoneNumber(twilioPhoneNumber),
                    message
                ).create();
                
                System.out.println("✅ REAL SMS sent to " + to + ": " + message);
            } else {
                // Dummy implementation for development
                System.out.println("📱 [DUMMY SMS] To: " + to + " | Message: " + message);
            }
            
        } catch (Exception e) {
            System.err.println("Failed to send SMS: " + e.getMessage());
            // Fallback to dummy implementation
            System.out.println("📱 [DUMMY FALLBACK] To: " + to + " | Message: " + message);
        }
    }
    
    private void logNotification(String to, String message, String type) {
        System.out.println(type + " sent to " + to + ": " + message);
    }
    
    public void sendPaymentConfirmation(String phoneNumber, Double amount) {
        String message = String.format(
            "Payment of %.2f Pula received. Your neighborhood watch subscription is active. Thank you!",
            amount
        );
        sendSms(phoneNumber, message);
    }
    
    public void sendPatrolViolationAlertToAdmin(String adminPhone, UserProfile officer, PatrolViolation violation) {
        String message = String.format(
            "ALERT: Officer %s %s has compliance rate of %.1f%%. Officer temporarily suspended.",
            officer.getFirstName(), officer.getLastName(), violation.getComplianceRate()
        );
        sendSms(adminPhone, message);
    }
    
    public void sendEmergencyAlertToOfficer(String officerPhone, EmergencyAlert alert, UserProfile member) {
        String message = String.format(
            "EMERGENCY: %s alert from %s %s at %s. Description: %s",
            alert.getAlertType(), member.getFirstName(), member.getLastName(),
            alert.getLocation(), alert.getDescription()
        );
        sendSms(officerPhone, message);
    }
    
    public void sendEmergencyAlertToMember(String memberPhone, EmergencyAlert alert) {
        String message = String.format(
            "EMERGENCY: %s alert in your neighborhood at %s. Please stay safe.",
            alert.getAlertType(), alert.getLocation()
        );
        sendSms(memberPhone, message);
    }
    
    public void sendPatrolViolationAlertToMember(String memberPhone, UserProfile officer, PatrolViolation violation) {
        String message = String.format(
            "NOTICE: Officer %s %s has compliance issues. Alternative arrangements in progress.",
            officer.getFirstName(), officer.getLastName()
        );
        sendSms(memberPhone, message);
    }
}