package com.neighborhoodwatch.repository;

import com.neighborhoodwatch.model.CommunityPost;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CommunityPostRepository extends JpaRepository<CommunityPost, String> {
    
    // Find all main posts (not replies)
    List<CommunityPost> findByParentPostIdIsNullOrderByCreatedAtDesc();
    
    // Find replies for a specific post
    List<CommunityPost> findByParentPostIdOrderByCreatedAtAsc(String parentPostId);
    
    // Find posts by category
    List<CommunityPost> findByCategoryAndParentPostIdIsNullOrderByCreatedAtDesc(String category);
    
    // Find pinned posts
    List<CommunityPost> findByIsPinnedTrueAndParentPostIdIsNullOrderByCreatedAtDesc();
}