// src/services/forumService.js

const API_BASE_URL = '/api/community/posts';

// Get all posts (both main posts and replies)
export const fetchAllPosts = async () => {
  try {
    const response = await fetch(API_BASE_URL);
    if (!response.ok) throw new Error('Failed to fetch posts');
    const posts = await response.json();
    return posts;
  } catch (error) {
    console.error('Error fetching posts:', error);
    throw error;
  }
};

// Get posts by category
export const fetchPostsByCategory = async (category) => {
  try {
    const response = await fetch(`${API_BASE_URL}?category=${category}`);
    if (!response.ok) throw new Error('Failed to fetch posts by category');
    return await response.json();
  } catch (error) {
    console.error('Error fetching posts by category:', error);
    throw error;
  }
};

// Create new post (main post or reply)
export const createPost = async (postData) => {
  try {
    const response = await fetch(API_BASE_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(postData),
    });

    if (!response.ok) throw new Error('Failed to create post');
    return await response.json();
  } catch (error) {
    console.error('Error creating post:', error);
    throw error;
  }
};

// Like a post
export const likePost = async (postId) => {
  try {
    const response = await fetch(`${API_BASE_URL}/${postId}/like`, {
      method: 'POST',
    });
    if (!response.ok) throw new Error('Failed to like post');
    return await response.json();
  } catch (error) {
    console.error('Error liking post:', error);
    throw error;
  }
};

// Pin/unpin a post
export const togglePinPost = async (postId) => {
  try {
    const response = await fetch(`${API_BASE_URL}/${postId}/pin`, {
      method: 'POST',
    });
    if (!response.ok) throw new Error('Failed to toggle pin post');
    return await response.json();
  } catch (error) {
    console.error('Error toggling pin post:', error);
    throw error;
  }
};

// Delete post
export const deletePost = async (postId) => {
  try {
    const response = await fetch(`${API_BASE_URL}/${postId}`, {
      method: 'DELETE',
    });
    if (!response.ok) throw new Error('Failed to delete post');
    return true;
  } catch (error) {
    console.error('Error deleting post:', error);
    throw error;
  }
};