// src/utils/forumUtils.js

// Generate UUID
export const generateId = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

// Format date
export const formatDate = (isoString) => {
  const options = { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  };
  return new Date(isoString).toLocaleDateString(undefined, options);
};

// Create new forum post
export const createNewPost = (title, content, category, memberId) => {
  return {
    id: generateId(),
    memberId: memberId,
    title: title.trim(),
    content: content.trim(),
    category: category,
    parentPostId: null, // This is a main post, not a reply
    likeCount: 0,
    isPinned: false,
    createdAt: new Date().toISOString(),
    replies: []
  };
};

// Create new reply
export const createNewReply = (content, parentPostId, memberId) => {
  return {
    id: generateId(),
    memberId: memberId,
    title: '', // Replies don't need titles
    content: content.trim(),
    category: null, // Replies inherit category from parent
    parentPostId: parentPostId,
    likeCount: 0,
    isPinned: false,
    createdAt: new Date().toISOString()
  };
};

// Organize posts into threads with replies
export const organizePostsIntoThreads = (posts) => {
  const mainPosts = posts.filter(post => post.parentPostId === null);
  const replies = posts.filter(post => post.parentPostId !== null);
  
  // Add replies to their parent posts
  mainPosts.forEach(post => {
    post.replies = replies
      .filter(reply => reply.parentPostId === post.id)
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  });
  
  // Sort main posts: pinned first, then by date (newest first)
  return mainPosts.sort((a, b) => {
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    return new Date(b.createdAt) - new Date(a.createdAt);
  });
};

// Validate post
export const validatePost = (post) => {
  const errors = {};
  
  if (!post.id) errors.id = "ID is required";
  if (!post.memberId) errors.memberId = "Member ID is required";
  
  if (post.isMainPost()) {
    if (!post.title?.trim()) errors.title = "Title is required";
    if (!post.category) errors.category = "Category is required";
  }
  
  if (!post.content?.trim()) errors.content = "Content is required";
  if (!post.createdAt) errors.createdAt = "Create date is required";
  
  return errors;
};