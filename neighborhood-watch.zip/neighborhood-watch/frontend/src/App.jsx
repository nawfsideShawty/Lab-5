import React, { useState, useEffect } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { ThemeProvider, createTheme } from '@mui/material/styles'
import CssBaseline from '@mui/material/CssBaseline'
import { Box, CircularProgress, Snackbar, Alert } from '@mui/material'
import keycloak, { initKeycloak, logout } from './keycloak'
import LandingPage from './components/LandingPage'
import Navbar from './components/Navbar'
import AdminDashboard from './components/AdminDashboard'
import PatrolStatistics from './components/PatrolStatistics'
import EmergencyAlert from './components/EmergencyAlert'
import Payment from './components/Payment'
import MemberDashboard from './components/MemberDashboard'
import SecurityOfficerDashboard from './components/SecurityOfficerDashboard'
import CommunityForum from './components/CommunityForum'
import PatrolScans from './components/PatrolScans'
import UserSync from './components/UserSync'
import MemberQRCode from './components/MemberQRCode'
import './App.css'

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
    background: {
      default: '#f5f5f5',
    },
  },
});

// Function to determine user type from Keycloak roles
const getUserTypeFromRoles = (roles) => {
  if (roles.includes('ADMIN')) return 'ADMIN';
  if (roles.includes('SECURITY_OFFICER')) return 'SECURITY_OFFICER';
  return 'MEMBER'; // Default to member
};

function App() {
  const [authenticated, setAuthenticated] = useState(false)
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState(null)
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'info' })

  useEffect(() => {
    const handleAuthenticated = () => {
      setAuthenticated(true);
      
      // Extract user info and roles from Keycloak token
      const tokenParsed = keycloak.tokenParsed;
      const roles = keycloak.realmAccess?.roles || [];
      const resourceRoles = keycloak.resourceAccess?.['frontend-client']?.roles || [];
      const allRoles = [...roles, ...resourceRoles];
      
      const userInfo = {
        username: tokenParsed?.preferred_username,
        email: tokenParsed?.email,
        firstName: tokenParsed?.given_name,
        lastName: tokenParsed?.family_name,
        userType: getUserTypeFromRoles(allRoles),
        keycloakId: tokenParsed?.sub,
        roles: allRoles
      };
      
      setUser(userInfo);
      setLoading(false);
      
      localStorage.setItem('token', keycloak.token);
      
      console.log('User roles:', allRoles);
      console.log('User type determined:', userInfo.userType);
      
      if (tokenParsed?.given_name) {
        setNotification({
          open: true,
          message: `Welcome back, ${tokenParsed.given_name}! (${userInfo.userType})`,
          severity: 'success'
        });
      }
    };

    const handleNotAuthenticated = () => {
      setAuthenticated(false);
      setLoading(false);
    };

    initKeycloak(handleAuthenticated, handleNotAuthenticated);
  }, [])

  const handleLogout = () => {
    // Clear all state before logging out
    setAuthenticated(false);
    setUser(null);
    setLoading(false);
    logout();
  }

  const handleCloseNotification = () => {
    setNotification({ ...notification, open: false })
  }

  if (loading) {
    return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh">
          <CircularProgress />
        </Box>
      </ThemeProvider>
    )
  }

  if (!authenticated) {
    return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <LandingPage />
      </ThemeProvider>
    )
  }

  const isAdmin = user?.userType === 'ADMIN'
  const isSecurityOfficer = user?.userType === 'SECURITY_OFFICER'
  const isMember = user?.userType === 'MEMBER'

  console.log('Current user:', user);
  console.log('isAdmin:', isAdmin, 'isSecurityOfficer:', isSecurityOfficer, 'isMember:', isMember);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      
      <UserSync user={user} keycloak={keycloak} />
      
      <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
        <Navbar user={user} onLogout={handleLogout} />
        <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" />} />
            <Route path="/dashboard" element={
              isAdmin ? <AdminDashboard /> :
              isSecurityOfficer ? <SecurityOfficerDashboard /> :
              <MemberDashboard />
            } />
            <Route path="/admin/*" element={
              isAdmin ? <AdminDashboard /> : <Navigate to="/dashboard" />
            } />
            <Route path="/stats" element={<PatrolStatistics />} />
            <Route path="/emergency" element={<EmergencyAlert />} />
            <Route path="/payment" element={<Payment />} />
            <Route path="/community" element={<CommunityForum />} />
            <Route path="/patrol-scans" element={
              isSecurityOfficer ? <PatrolScans /> : <Navigate to="/dashboard" />
            } />
            <Route path="/my-qr-code" element={<MemberQRCode />} />
          </Routes>
        </Box>
      </Box>

      <Snackbar 
        open={notification.open} 
        autoHideDuration={6000} 
        onClose={handleCloseNotification}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={handleCloseNotification} severity={notification.severity}>
          {notification.message}
        </Alert>
      </Snackbar>
    </ThemeProvider>
  )
}

export default App