import Keycloak from 'keycloak-js';

const keycloakConfig = {
  url: 'http://localhost:8081',
  realm: 'neighborhood-watch',
  clientId: 'frontend-client'
};

const keycloak = new Keycloak(keycloakConfig);

let initialized = false;
let initPromise = null;

export const initKeycloak = (onAuthenticatedCallback, onNotAuthenticatedCallback) => {
  // Clear any existing tokens on initialization
  if (!localStorage.getItem('preserve_session')) {
    localStorage.removeItem('token');
  }

  if (initialized) {
    if (keycloak.authenticated) {
      onAuthenticatedCallback();
    } else {
      onNotAuthenticatedCallback();
    }
    return;
  }

  if (initPromise) {
    initPromise.then(() => {
      if (keycloak.authenticated) {
        onAuthenticatedCallback();
      } else {
        onNotAuthenticatedCallback();
      }
    });
    return;
  }

  initPromise = keycloak.init({
    onLoad: 'check-sso',
    pkceMethod: 'S256',
    checkLoginIframe: false
  })
  .then((authenticated) => {
    initialized = true;
    if (authenticated) {
      localStorage.setItem('token', keycloak.token);
      localStorage.setItem('preserve_session', 'true');
      onAuthenticatedCallback();
    } else {
      localStorage.removeItem('preserve_session');
      if (onNotAuthenticatedCallback) {
        onNotAuthenticatedCallback();
      }
    }
  })
  .catch((error) => {
    console.error('Keycloak initialization failed:', error);
    initialized = false;
    initPromise = null;
    localStorage.removeItem('preserve_session');
    if (onNotAuthenticatedCallback) {
      onNotAuthenticatedCallback();
    }
  });
};

// Add token refresh
keycloak.onTokenExpired = () => {
  keycloak.updateToken(30).then((refreshed) => {
    if (refreshed) {
      localStorage.setItem('token', keycloak.token);
    }
  }).catch(() => {
    keycloak.login();
  });
};

export const login = () => {
  keycloak.login({
    redirectUri: window.location.origin + '/dashboard',
    prompt: 'login'
  });
};

export const register = () => {
  keycloak.register({
    redirectUri: window.location.origin + '/dashboard'
  });
};

export const logout = () => {
  localStorage.removeItem('token');
  localStorage.removeItem('preserve_session');
  
  // Clear all cookies and session data
  keycloak.clearToken();
  
  // Logout with redirect to landing page
  keycloak.logout({ redirectUri: window.location.origin });
};

export default keycloak;