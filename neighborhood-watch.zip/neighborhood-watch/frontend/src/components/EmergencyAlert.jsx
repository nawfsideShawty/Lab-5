// src/components/EmergencyAlert.jsx
import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  Box,
  Card,
  CardContent,
  Grid
} from '@mui/material';
import { Warning, History } from '@mui/icons-material';

const EmergencyAlert = () => {
  const [open, setOpen] = useState(false);
  const [alertType, setAlertType] = useState('SECURITY');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [pastAlerts, setPastAlerts] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchPastAlerts();
  }, []);

  const fetchPastAlerts = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8080/api/emergency/alerts', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        setPastAlerts(data);
      }
    } catch (error) {
      console.error('Failed to fetch past alerts:', error);
    }
  };

  const handleSubmit = async () => {
    try {
      const token = localStorage.getItem('token');
      
      const response = await fetch('http://localhost:8080/api/emergency/alert', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          alertType,
          location,
          description
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to send emergency alert');
      }
      
      setSubmitted(true);
      setOpen(false);
      
      // Reset form
      setAlertType('SECURITY');
      setLocation('');
      setDescription('');
      
      // Refresh alerts list
      fetchPastAlerts();
      
    } catch (error) {
      console.error('Failed to send emergency alert:', error);
      setError('Failed to send emergency alert. Please try again.');
    }
  };

  if (submitted) {
    return (
      <Container maxWidth="sm" sx={{ mt: 4 }}>
        <Alert severity="success">
          Emergency alert sent! Security officers and neighbors have been notified.
        </Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4 }}>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 4, textAlign: 'center' }}>
            <Warning color="error" sx={{ fontSize: 60, mb: 2 }} />
            <Typography variant="h4" color="error" gutterBottom>
              Emergency Alert
            </Typography>
            <Typography variant="body1" sx={{ mb: 3 }}>
              Use this only for genuine emergencies. This will notify all security officers and neighborhood members immediately.
            </Typography>
            
            <Button
              variant="contained"
              color="error"
              size="large"
              onClick={() => setOpen(true)}
            >
              Raise Emergency Alert
            </Button>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
              <History sx={{ mr: 1 }} />
              Recent Emergency Alerts
            </Typography>
            {pastAlerts.length === 0 ? (
              <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', py: 4 }}>
                No recent emergency alerts
              </Typography>
            ) : (
              pastAlerts.slice(0, 5).map((alert) => (
                <Card key={alert.id} sx={{ mb: 2 }}>
                  <CardContent>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', mb: 1 }}>
                      <Typography variant="subtitle1" fontWeight="bold">
                        {alert.alertType}
                      </Typography>
                      <Box sx={{ 
                        px: 1, 
                        py: 0.5, 
                        borderRadius: 1,
                        bgcolor: alert.status === 'ACTIVE' ? 'error.light' : 'success.light',
                        color: 'white',
                        fontSize: '0.75rem'
                      }}>
                        {alert.status}
                      </Box>
                    </Box>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      {alert.location}
                    </Typography>
                    <Typography variant="body2">
                      {alert.description}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {new Date(alert.createdAt).toLocaleString()}
                    </Typography>
                  </CardContent>
                </Card>
              ))
            )}
          </Paper>
        </Grid>
      </Grid>

      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Emergency Alert Details</DialogTitle>
        <DialogContent>
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          
          <FormControl fullWidth sx={{ mb: 2, mt: 1 }}>
            <InputLabel>Emergency Type</InputLabel>
            <Select
              value={alertType}
              onChange={(e) => setAlertType(e.target.value)}
              label="Emergency Type"
            >
              <MenuItem value="SECURITY">Security Threat</MenuItem>
              <MenuItem value="MEDICAL">Medical Emergency</MenuItem>
              <MenuItem value="FIRE">Fire</MenuItem>
              <MenuItem value="OTHER">Other</MenuItem>
            </Select>
          </FormControl>
          
          <TextField
            fullWidth
            label="Your Location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            sx={{ mb: 2 }}
            placeholder="e.g., 123 Main Street, House 45"
          />
          
          <TextField
            fullWidth
            label="Emergency Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            multiline
            rows={4}
            placeholder="Please describe the emergency situation in detail..."
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Cancel</Button>
          <Button 
            onClick={handleSubmit} 
            variant="contained" 
            color="error"
            disabled={!location || !description}
          >
            Send Emergency Alert
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default EmergencyAlert;