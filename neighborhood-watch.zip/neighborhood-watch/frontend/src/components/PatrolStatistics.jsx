// src/components/PatrolStatistics.jsx
import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  LinearProgress,
  Box,
  Alert,
  Button
} from '@mui/material';
import { 
  TrendingUp, 
  Warning, 
  CheckCircle, 
  LocationOn,
  Refresh
} from '@mui/icons-material';

const PatrolStatistics = () => {
  const [stats, setStats] = useState({});
  const [recentScans, setRecentScans] = useState([]);
  const [violations, setViolations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchStats();
    fetchRecentScans();
    fetchViolations();
  }, []);

  const fetchStats = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8080/api/patrol/stats', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      } else {
        throw new Error('Failed to fetch stats');
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error);
      setError('Failed to load statistics');
    } finally {
      setLoading(false);
    }
  };

  const fetchRecentScans = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8080/api/patrol/recent-scans', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        setRecentScans(data);
      }
    } catch (error) {
      console.error('Failed to fetch recent scans:', error);
    }
  };

  const fetchViolations = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8080/api/patrol/violations', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        setViolations(data);
      }
    } catch (error) {
      console.error('Failed to fetch violations:', error);
    }
  };

  const refreshData = () => {
    setLoading(true);
    setError('');
    fetchStats();
    fetchRecentScans();
    fetchViolations();
  };

  const StatCard = ({ icon, title, value, subtitle, color = 'primary' }) => (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          {icon}
          <Typography variant="h6" sx={{ ml: 1 }}>
            {title}
          </Typography>
        </Box>
        <Typography variant="h4" color={color} gutterBottom>
          {value}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {subtitle}
        </Typography>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Box display="flex" justifyContent="center" alignItems="center" minHeight="200px">
          <Typography>Loading statistics...</Typography>
        </Box>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" gutterBottom>
          Patrol Statistics
        </Typography>
        <Button 
          startIcon={<Refresh />} 
          onClick={refreshData}
          variant="outlined"
        >
          Refresh
        </Button>
      </Box>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            icon={<TrendingUp color="primary" />}
            title="Weekly Scans"
            value={stats.weeklyScans || 0}
            subtitle="This week"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            icon={<CheckCircle color="success" />}
            title="Compliance Rate"
            value={`${stats.complianceRate || 0}%`}
            subtitle="Officer performance"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            icon={<Warning color="warning" />}
            title="Active Alerts"
            value={stats.activeAlerts || 0}
            subtitle="Requiring attention"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            icon={<LocationOn color="info" />}
            title="Patrol Coverage"
            value={`${stats.coverageRate || 0}%`}
            subtitle="Area covered"
          />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Compliance Overview
            </Typography>
            <Box sx={{ mb: 2 }}>
              <Typography variant="body2" gutterBottom>
                Target: 80% Minimum
              </Typography>
              <LinearProgress 
                variant="determinate" 
                value={stats.complianceRate || 0}
                color={stats.complianceRate >= 80 ? 'success' : 'warning'}
                sx={{ height: 10, borderRadius: 5 }}
              />
              <Typography variant="body2" sx={{ mt: 1 }}>
                Current: {stats.complianceRate || 0}%
              </Typography>
            </Box>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Recent Patrol Scans
            </Typography>
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow>
                    <TableCell>Officer</TableCell>
                    <TableCell>Location</TableCell>
                    <TableCell>Time</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {recentScans.slice(0, 5).map((scan) => (
                    <TableRow key={scan.id}>
                      <TableCell>
                        {scan.officer?.firstName} {scan.officer?.lastName}
                      </TableCell>
                      <TableCell>{scan.house?.address}</TableCell>
                      <TableCell>
                        {new Date(scan.scanTime).toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>
      </Grid>

      {/* Patrol Violations Section */}
      {violations.length > 0 && (
        <Grid item xs={12} sx={{ mt: 3 }}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom color="warning">
              Recent Patrol Violations
            </Typography>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Officer</TableCell>
                    <TableCell>Date</TableCell>
                    <TableCell>Expected Scans</TableCell>
                    <TableCell>Actual Scans</TableCell>
                    <TableCell>Compliance Rate</TableCell>
                    <TableCell>Status</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {violations.map((violation) => (
                    <TableRow key={violation.id}>
                      <TableCell>{violation.officerName}</TableCell>
                      <TableCell>{new Date(violation.violationDate).toLocaleDateString()}</TableCell>
                      <TableCell>{violation.expectedScans}</TableCell>
                      <TableCell>{violation.actualScans}</TableCell>
                      <TableCell>
                        <Box sx={{ 
                          color: violation.complianceRate >= 80 ? 'success.main' : 'warning.main',
                          fontWeight: 'bold'
                        }}>
                          {violation.complianceRate}%
                        </Box>
                      </TableCell>
                      <TableCell>
                        <Box sx={{ 
                          display: 'inline-block', 
                          px: 1, 
                          py: 0.5, 
                          borderRadius: 1,
                          bgcolor: 
                            violation.status === 'RESOLVED' ? 'success.light' : 
                            violation.status === 'PENDING' ? 'warning.light' : 'error.light',
                          color: 'white',
                          fontSize: '0.75rem'
                        }}>
                          {violation.status}
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>
      )}
    </Container>
  );
};

export default PatrolStatistics;