import React from 'react';
import { Container, Paper, Typography, Button, Box } from '@mui/material';
import { login } from '../keycloak';

const Login = () => {
  const handleLogin = () => {
    login();
  };

  return (
    <Container component="main" maxWidth="sm">
      <Box sx={{ mt: 8, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Paper elevation={3} sx={{ p: 4, width: '100%' }}>
          <Typography component="h1" variant="h5" align="center" gutterBottom>
            Neighborhood Watch Login
          </Typography>
          <Typography variant="body2" align="center" sx={{ mb: 3 }}>
            Secure authentication with Keycloak
          </Typography>
          <Button
            fullWidth
            variant="contained"
            sx={{ mt: 3, mb: 2 }}
            onClick={handleLogin}
          >
            Sign In with Keycloak
          </Button>
        </Paper>
      </Box>
    </Container>
  );
};

export default Login;