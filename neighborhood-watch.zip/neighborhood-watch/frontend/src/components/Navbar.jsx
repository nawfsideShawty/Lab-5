// src/components/Navbar.jsx
import React, { useState } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  Menu,
  MenuItem,
  IconButton,
  Chip
} from '@mui/material';
import { AccountCircle, Security, ExitToApp } from '@mui/icons-material';
import { Link, useNavigate } from 'react-router-dom';

const Navbar = ({ user, onLogout }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const navigate = useNavigate();

  const handleMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    onLogout();
    handleClose();
  };

  const getUserTypeColor = (userType) => {
    switch (userType) {
      case 'ADMIN': return 'error';
      case 'SECURITY_OFFICER': return 'warning';
      case 'MEMBER': return 'success';
      default: return 'default';
    }
  };

  return (
    <AppBar position="static" elevation={2}>
      <Toolbar>
        <Box sx={{ display: 'flex', alignItems: 'center', flexGrow: 1 }}>
          <Security sx={{ mr: 2 }} />
          <Typography 
            variant="h6" 
            component={Link} 
            to="/" 
            sx={{ 
              textDecoration: 'none', 
              color: 'inherit',
              fontWeight: 'bold'
            }}
          >
            Neighborhood Watch
          </Typography>
        </Box>
        
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
          {/* Admin Links */}
          {user?.userType === 'ADMIN' && (
            <>
              <Button color="inherit" component={Link} to="/admin">
                Admin Dashboard
              </Button>
              <Button color="inherit" component={Link} to="/stats">
                Statistics
              </Button>
            </>
          )}
          
          {/* Security Officer Links */}
          {user?.userType === 'SECURITY_OFFICER' && (
            <Button color="inherit" component={Link} to="/patrol-scans">
              Patrol Scans
            </Button>
          )}
          
          {/* Member Links */}
          {user?.userType === 'MEMBER' && (
            <>
              <Button color="inherit" component={Link} to="/community">
                Community
              </Button>
              <Button color="inherit" component={Link} to="/stats">
                Statistics
              </Button>
              <Button color="inherit" component={Link} to="/emergency">
                Emergency
              </Button>
              <Button color="inherit" component={Link} to="/payment">
                Payment
              </Button>
            </>
          )}
          
          {/* Common Links */}
          <Button color="inherit" component={Link} to="/dashboard">
            Dashboard
          </Button>

          {/* User Info & Menu */}
          <Chip 
            icon={<AccountCircle />}
            label={`${user?.firstName || 'User'}`}
            color={getUserTypeColor(user?.userType)}
            variant="outlined"
            sx={{ color: 'white', borderColor: 'white' }}
          />
          
          <IconButton
            size="large"
            aria-label="account of current user"
            aria-controls="menu-appbar"
            aria-haspopup="true"
            onClick={handleMenu}
            color="inherit"
          >
            <AccountCircle />
          </IconButton>
          <Menu
            id="menu-appbar"
            anchorEl={anchorEl}
            anchorOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            keepMounted
            transformOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
            open={Boolean(anchorEl)}
            onClose={handleClose}
          >
            <MenuItem disabled>
              <Box>
                <Typography variant="subtitle2">
                  {user?.firstName} {user?.lastName}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {user?.email}
                </Typography>
                <Typography variant="caption" display="block" color="text.secondary">
                  {user?.userType}
                </Typography>
              </Box>
            </MenuItem>
            <MenuItem onClick={handleClose}>Profile</MenuItem>
            <MenuItem onClick={handleLogout}>
              <ExitToApp sx={{ mr: 1 }} />
              Logout
            </MenuItem>
          </Menu>
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;