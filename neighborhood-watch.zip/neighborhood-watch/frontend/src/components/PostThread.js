// src/components/PostThread.js
import React, { useState } from 'react';
import { formatDate } from '../utils/forumUtils';

const PostThread = ({ post, currentMemberId, onReply, onLike, onDelete }) => {
  const [showReplyForm, setShowReplyForm] = useState(false);
  const [replyContent, setReplyContent] = useState('');

  const handleSubmitReply = (e) => {
    e.preventDefault();
    if (replyContent.trim()) {
      onReply(post.id, replyContent.trim());
      setReplyContent('');
      setShowReplyForm(false);
    }
  };

  const canModify = currentMemberId === post.memberId;

  return (
    <div className={`post-thread ${post.isPinned ? 'pinned' : ''}`}>
      {post.isPinned && <div className="pinned-badge">📌 Pinned</div>}
      
      {/* Main Post */}
      <div className="main-post">
        <div className="post-header">
          <div className="post-meta">
            <span className="post-category">{post.category}</span>
            <span className="post-author">By: {post.memberId}</span>
            <span className="post-date">{formatDate(post.createdAt)}</span>
          </div>
          <div className="post-actions">
            {canModify && (
              <button 
                onClick={() => onDelete(post.id)}
                className="btn-delete"
                title="Delete post"
              >
                🗑️
              </button>
            )}
          </div>
        </div>
        
        <h3 className="post-title">{post.title}</h3>
        <div className="post-content">{post.content}</div>
        
        <div className="post-footer">
          <button 
            onClick={() => onLike(post.id)}
            className="btn-like"
          >
            👍 {post.likeCount}
          </button>
          <button 
            onClick={() => setShowReplyForm(!showReplyForm)}
            className="btn-reply"
          >
            💬 Reply
          </button>
          <span className="reply-count">
            {post.replies.length} {post.replies.length === 1 ? 'reply' : 'replies'}
          </span>
        </div>
      </div>

      {/* Reply Form */}
      {showReplyForm && (
        <form onSubmit={handleSubmitReply} className="reply-form">
          <textarea
            value={replyContent}
            onChange={(e) => setReplyContent(e.target.value)}
            placeholder="Write your reply..."
            rows="3"
            required
          />
          <div className="reply-actions">
            <button type="button" onClick={() => setShowReplyForm(false)}>
              Cancel
            </button>
            <button type="submit">Post Reply</button>
          </div>
        </form>
      )}

      {/* Replies */}
      {post.replies.length > 0 && (
        <div className="replies">
          {post.replies.map(reply => (
            <div key={reply.id} className="reply">
              <div className="reply-header">
                <span className="reply-author">{reply.memberId}</span>
                <span className="reply-date">{formatDate(reply.createdAt)}</span>
                {currentMemberId === reply.memberId && (
                  <button 
                    onClick={() => onDelete(reply.id)}
                    className="btn-delete-small"
                  >
                    🗑️
                  </button>
                )}
              </div>
              <div className="reply-content">{reply.content}</div>
              <button 
                onClick={() => onLike(reply.id)}
                className="btn-like-small"
              >
                👍 {reply.likeCount}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default PostThread;