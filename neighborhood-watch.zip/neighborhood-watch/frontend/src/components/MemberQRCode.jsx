import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  Box,
  Alert,
  CircularProgress,
  Button,
  TextField
} from '@mui/material';
import { QrCode, Download, Share, Refresh, Edit } from '@mui/icons-material';
import QRCode from 'qrcode.react';

const MemberQRCode = () => {
  const [qrData, setQrData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [houseAddress, setHouseAddress] = useState('');
  const [isEditing, setIsEditing] = useState(true);

  useEffect(() => {
    // Load saved house address from localStorage
    const savedAddress = localStorage.getItem('houseAddress');
    if (savedAddress) {
      setHouseAddress(savedAddress);
      setIsEditing(false);
      generateQRCode(savedAddress);
    }
  }, []);

  const generateQRCode = (address) => {
    setLoading(true);
    try {
      // Get user info from token or use placeholder
      const token = localStorage.getItem('token');
      let userInfo = {
        id: 'user-' + Math.random().toString(36).substr(2, 9),
        name: 'Resident'
      };

      if (token) {
        try {
          // Try to decode JWT token to get user info
          const tokenPayload = JSON.parse(atob(token.split('.')[1]));
          userInfo = {
            id: tokenPayload.sub || userInfo.id,
            name: tokenPayload.given_name || tokenPayload.preferred_username || userInfo.name
          };
        } catch (e) {
          console.log('Could not decode token, using default user info');
        }
      }

      // Generate unique QR content
      const qrContent = JSON.stringify({
        type: 'NEIGHBORHOOD_WATCH',
        memberId: userInfo.id,
        memberName: userInfo.name,
        houseAddress: address,
        timestamp: Date.now(),
        version: '1.0'
      });

      // Alternative simpler format for easier scanning:
      const simpleQRContent = `NEIGHBORHOOD_WATCH|MEMBER:${userInfo.id}|ADDRESS:${address}|TIME:${Date.now()}`;

      setQrData({
        qrContent: simpleQRContent,
        memberId: userInfo.id,
        memberName: userInfo.name,
        houseAddress: address,
        generatedAt: new Date().toISOString()
      });

      // Save to localStorage
      localStorage.setItem('houseAddress', address);
      localStorage.setItem('memberQRData', JSON.stringify({
        memberId: userInfo.id,
        houseAddress: address
      }));

    } catch (error) {
      console.error('Failed to generate QR code:', error);
      setError('Failed to generate QR code');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveAddress = () => {
    if (!houseAddress.trim()) {
      setError('Please enter your house address');
      return;
    }
    setIsEditing(false);
    generateQRCode(houseAddress.trim());
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  const downloadQRCode = () => {
    const canvas = document.getElementById('member-qr-code');
    if (canvas) {
      const pngUrl = canvas
        .toDataURL("image/png")
        .replace("image/png", "image/octet-stream");
      const downloadLink = document.createElement("a");
      downloadLink.href = pngUrl;
      downloadLink.download = `house-qr-code-${houseAddress.replace(/\s+/g, '-')}.png`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
    }
  };

  const shareQRCode = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'My House QR Code - Neighborhood Watch',
          text: `QR Code for ${houseAddress}. Security officers can scan this during patrols.`,
          url: window.location.href,
        });
      } catch (error) {
        console.log('Sharing cancelled or failed:', error);
      }
    } else {
      // Fallback: copy QR data to clipboard
      navigator.clipboard.writeText(qrData?.qrContent || '');
      alert('QR code data copied to clipboard!');
    }
  };

  if (loading) {
    return (
      <Container maxWidth="md" sx={{ mt: 4, mb: 4, textAlign: 'center' }}>
        <CircularProgress />
        <Typography variant="body1" sx={{ mt: 2 }}>
          Generating your QR code...
        </Typography>
      </Container>
    );
  }

  return (
    <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>
        Your House QR Code
      </Typography>
      
      <Typography variant="body1" color="text.secondary" sx={{ mb: 4 }}>
        Security officers will scan this QR code during patrols to verify your property's security status.
        Display this code in a visible location near your entrance.
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {isEditing ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h6" gutterBottom>
            Enter Your House Address
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            This address will be encoded in your QR code for security officers.
          </Typography>
          
          <TextField
            fullWidth
            label="House Address"
            value={houseAddress}
            onChange={(e) => setHouseAddress(e.target.value)}
            placeholder="e.g., 123 Main Street, Apt 4B"
            sx={{ mb: 3 }}
            multiline
            rows={2}
          />
          
          <Button 
            variant="contained" 
            onClick={handleSaveAddress}
            size="large"
          >
            Generate QR Code
          </Button>
        </Paper>
      ) : (
        <>
          <Paper sx={{ p: 4, textAlign: 'center' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">
                Your QR Code
              </Typography>
              <Button 
                startIcon={<Edit />} 
                onClick={handleEdit}
                size="small"
              >
                Edit Address
              </Button>
            </Box>

            {qrData && (
              <>
                <Box sx={{ mb: 3 }}>
                  <QRCode
                    id="member-qr-code"
                    value={qrData.qrContent}
                    size={256}
                    level="H"
                    includeMargin
                  />
                </Box>

                <Box sx={{ mb: 3 }}>
                  <Typography variant="body1" gutterBottom>
                    <strong>Address:</strong> {houseAddress}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <strong>Member ID:</strong> {qrData.memberId}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <strong>Generated:</strong> {new Date(qrData.generatedAt).toLocaleDateString()}
                  </Typography>
                </Box>

                <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
                  <Button
                    variant="outlined"
                    startIcon={<Download />}
                    onClick={downloadQRCode}
                  >
                    Download
                  </Button>
                  
                  <Button
                    variant="outlined"
                    startIcon={<Share />}
                    onClick={shareQRCode}
                  >
                    Share
                  </Button>
                </Box>
              </>
            )}
          </Paper>

          {/* Instructions */}
          <Paper sx={{ p: 3, mt: 3, bgcolor: 'info.light' }}>
            <Typography variant="h6" gutterBottom>
              📍 Display Instructions
            </Typography>
            <Typography variant="body2" component="div">
              <ul>
                <li>Print and laminate the QR code for durability</li>
                <li>Place it in a visible location near your main entrance</li>
                <li>Ensure it's at eye level (approximately 1.5-2 meters high)</li>
                <li>Keep the area well-lit for easy scanning</li>
                <li>Make sure the code is not obstructed by plants or decorations</li>
              </ul>
            </Typography>
          </Paper>

          {/* For Security Officers */}
          <Paper sx={{ p: 3, mt: 3, bgcolor: 'success.light' }}>
            <Typography variant="h6" gutterBottom>
              🔒 For Security Officers
            </Typography>
            <Typography variant="body2">
              When scanning this QR code, you'll receive the house address and member information 
              for patrol verification. The scan will be recorded in the system automatically.
            </Typography>
          </Paper>
        </>
      )}
    </Container>
  );
};

export default MemberQRCode;