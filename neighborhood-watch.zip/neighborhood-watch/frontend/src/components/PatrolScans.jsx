// src/components/PatrolScans.jsx
import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  Button,
  Box,
  TextField,
  Card,
  CardContent,
  List,
  ListItem,
  ListItemText,
  Divider,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Grid 
} from '@mui/material';
import { QrCodeScanner, LocationOn, AccessTime } from '@mui/icons-material';
import keycloak from '../keycloak';
import QRScanner from './QRScanner';

const PatrolScans = () => {
  const [scans, setScans] = useState([]);
  const [openScanDialog, setOpenScanDialog] = useState(false);
  const [currentScan, setCurrentScan] = useState({
    houseId: '',
    comments: '',
    latitude: null,
    longitude: null
  });

  useEffect(() => {
    fetchRecentScans();
  }, []);

  const [scanDialogOpen, setScanDialogOpen] = useState(false);

  const fetchRecentScans = async () => {
    try {
      const token = keycloak.token;
      const response = await fetch('http://localhost:8080/api/patrol/my-scans', {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.status === 401) {
        await keycloak.updateToken(30);
        localStorage.setItem('token', keycloak.token);
        return fetchRecentScans();
      }
      
      const data = await response.json();
      setScans(data);
    } catch (error) {
      console.error('Failed to fetch scans:', error);
    }
  };

  const handleScanQR = () => {
    setScanDialogOpen(true);
  };

  const submitScan = async () => {
    try {
      const token = keycloak.token;
      const response = await fetch('http://localhost:8080/api/patrol/scan', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(currentScan)
      });
      
      if (response.status === 401) {
        await keycloak.updateToken(30);
        localStorage.setItem('token', keycloak.token);
        return submitScan();
      }
      
      setOpenScanDialog(false);
      setCurrentScan({ houseId: '', comments: '', latitude: null, longitude: null });
      fetchRecentScans();
    } catch (error) {
      console.error('Failed to submit scan:', error);
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
        <Typography variant="h4">
          Patrol Scans
        </Typography>
        <Button
          variant="contained"
          size="large"
          startIcon={<QrCodeScanner />}
          onClick={handleScanQR}
        >
          Scan QR Code
        </Button>
      </Box>

      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Recent Scans
            </Typography>
            <List>
              {scans.map((scan, index) => (
                <React.Fragment key={scan.id}>
                  <ListItem>
                    <ListItemText
                      primary={scan.house?.address || 'Unknown Address'}
                      secondary={
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mt: 1 }}>
                          <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <AccessTime sx={{ fontSize: 16, mr: 0.5 }} />
                            <Typography variant="caption">
                              {new Date(scan.scanTime).toLocaleString()}
                            </Typography>
                          </Box>
                          {scan.comments && (
                            <Typography variant="caption" color="text.secondary">
                              Note: {scan.comments}
                            </Typography>
                          )}
                        </Box>
                      }
                    />
                  </ListItem>
                  {index < scans.length - 1 && <Divider />}
                </React.Fragment>
              ))}
            </List>
          </Paper>
        </Grid>

        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Today's Summary
            </Typography>
            <Box sx={{ textAlign: 'center', py: 4 }}>
              <Typography variant="h3" color="primary">
                {scans.filter(scan => 
                  new Date(scan.scanTime).toDateString() === new Date().toDateString()
                ).length}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Scans Today
              </Typography>
            </Box>
          </Paper>
        </Grid>
      </Grid>

      {/* Scan Dialog */}
      <Dialog open={openScanDialog} onClose={() => setOpenScanDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Record Patrol Scan</DialogTitle>
        <DialogContent>
          <Box sx={{ mb: 2 }}>
            <Typography variant="body2" color="text.secondary">
              House: {currentScan.houseId}
            </Typography>
            {currentScan.latitude && (
              <Typography variant="body2" color="text.secondary">
                Location: {currentScan.latitude}, {currentScan.longitude}
              </Typography>
            )}
          </Box>
          <TextField
            fullWidth
            label="Comments (Optional)"
            multiline
            rows={3}
            value={currentScan.comments}
            onChange={(e) => setCurrentScan({...currentScan, comments: e.target.value})}
            placeholder="e.g., Gate left open, dogs outside, etc."
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenScanDialog(false)}>Cancel</Button>
          <Button onClick={submitScan} variant="contained">
            Submit Scan
          </Button>
        </DialogActions>
      </Dialog>
      <QRScanner
         open={scanDialogOpen}
         onClose={() => setScanDialogOpen(false)}
         onScanSuccess={(decodedText, decodedResult) => {
           setCurrentScan({
             ...currentScan,
             houseId: decodedText, // Assuming QR code contains house ID
             latitude: -24.6541, // Get from GPS in real implementation
             longitude: 25.9087
           });
           setOpenScanDialog(true);
         }}
      />
    </Container>
  );
};

export default PatrolScans;