import React, { useState, useEffect } from 'react'; 
import { 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  Button,
  Alert,
  Box,
  Card,
  CardContent,
  Tabs,
  Tab
} from '@mui/material';
import {
  PersonAdd,
  Security,
  AdminPanelSettings,
  Report,
  Download,
  Settings
} from '@mui/icons-material';
import keycloak from '../keycloak';

const AdminDashboard = () => {
  const [users, setUsers] = useState([]);
  const [stats, setStats] = useState({});
  const [tabValue, setTabValue] = useState(0);
  const [reportType, setReportType] = useState('WEEKLY');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchUsers();
    fetchStats();
  }, []);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const token = keycloak.token;
      console.log('🔍 Fetching users from backend...');
      
      const response = await fetch('http://localhost:8080/api/admin/users', {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      console.log('📡 Response status:', response.status);
      
      if (response.status === 401) {
        await keycloak.updateToken(30);
        localStorage.setItem('token', keycloak.token);
        return fetchUsers();
      }
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Backend error:', errorText);
        throw new Error(`HTTP ${response.status}: ${errorText}`);
      }
      
      const data = await response.json();
      console.log('✅ Users fetched:', data);
      setUsers(data);
      
    } catch (error) {
      console.error('💥 Failed to fetch users:', error);
      setError(`Failed to load users: ${error.message}`);
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const token = keycloak.token;
      const response = await fetch('http://localhost:8080/api/admin/stats', {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.status === 401) {
        await keycloak.updateToken(30);
        localStorage.setItem('token', keycloak.token);
        return fetchStats();
      }
      
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    }
  };

  // NEW: Redirect to Keycloak Admin Console for user management
  const redirectToKeycloakAdmin = () => {
    window.open('http://localhost:8081/admin/master/console/#/neighborhood-watch/users', '_blank');
  };

  const approveUser = async (userId) => {
    try {
      const token = keycloak.token;
      const response = await fetch(`http://localhost:8080/api/admin/users/${userId}/approve`, {
        method: 'PUT',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.status === 401) {
        await keycloak.updateToken(30);
        localStorage.setItem('token', keycloak.token);
        return approveUser(userId);
      }
      
      if (!response.ok) {
        throw new Error('Failed to approve user');
      }
      
      setSuccess('User approved successfully!');
      fetchUsers();
      
    } catch (error) {
      console.error('Failed to approve user:', error);
      setError('Failed to approve user - make sure backend is running');
    }
  };

  const generateReport = async () => {
    try {
      const token = keycloak.token;
      const response = await fetch(`http://localhost:8080/api/admin/reports/generate/${reportType.toLowerCase()}`, {
        method: 'POST',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.status === 401) {
        await keycloak.updateToken(30);
        localStorage.setItem('token', keycloak.token);
        return generateReport();
      }
      
      if (response.ok) {
        const report = await response.json();
        setSuccess(`${reportType} report generated successfully!`);
      }
    } catch (error) {
      console.error('Failed to generate report:', error);
      setError('Failed to generate report');
    }
  };

  const StatCard = ({ title, value, icon, color = 'primary' }) => (
    <Card>
      <CardContent>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box>
            <Typography color="text.secondary" gutterBottom>
              {title}
            </Typography>
            <Typography variant="h4" component="div">
              {value}
            </Typography>
          </Box>
          <Box sx={{ color: `${color}.main`, fontSize: '3rem' }}>
            {icon}
          </Box>
        </Box>
      </CardContent>
    </Card>
  );

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
          {error}
        </Alert>
      )}
      
      {success && (
        <Alert severity="success" sx={{ mb: 2 }} onClose={() => setSuccess('')}>
          {success}
        </Alert>
      )}
      
      <Typography variant="h4" gutterBottom sx={{ mb: 4, fontWeight: 'bold' }}>
        Admin Dashboard
      </Typography>
      
      {/* Statistics Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Total Users"
            value={stats.totalUsers || users.length}
            icon={<PersonAdd />}
            color="primary"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Security Officers"
            value={stats.securityOfficers || users.filter(u => u.userType === 'SECURITY_OFFICER').length}
            icon={<Security />}
            color="secondary"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Admins"
            value={stats.admins || users.filter(u => u.userType === 'ADMIN').length}
            icon={<AdminPanelSettings />}
            color="error"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard
            title="Pending Approval"
            value={users.filter(u => !u.isApproved).length}
            icon={<PersonAdd />}
            color="warning"
          />
        </Grid>
      </Grid>

      {/* Tabs for different admin functions */}
      <Paper sx={{ width: '100%', mb: 2 }}>
        <Tabs value={tabValue} onChange={handleTabChange}>
          <Tab label="User Management" />
          <Tab label="Reports" />
          <Tab label="System Monitoring" />
        </Tabs>
      </Paper>

      {tabValue === 0 && (
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column' }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h5" gutterBottom>
                  User Management
                </Typography>
                <Box>
                  <Button 
                    variant="contained" 
                    startIcon={<Settings />}
                    onClick={redirectToKeycloakAdmin}
                    sx={{ mr: 2 }}
                  >
                    Manage Users in Keycloak
                  </Button>
                  <Button 
                    variant="outlined"
                    startIcon={<Report />}
                    onClick={() => generateReport()}
                  >
                    Generate Report
                  </Button>
                </Box>
              </Box>

              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Name</TableCell>
                      <TableCell>Email</TableCell>
                      <TableCell>Type</TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell>Registration Date</TableCell>
                      <TableCell>Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell>{user.firstName} {user.lastName}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>
                          <Box sx={{ 
                            display: 'inline-block', 
                            px: 1, 
                            py: 0.5, 
                            borderRadius: 1,
                            bgcolor: 
                              user.userType === 'ADMIN' ? 'error.light' :
                              user.userType === 'SECURITY_OFFICER' ? 'warning.light' : 'success.light',
                            color: 'white',
                            fontSize: '0.75rem',
                            fontWeight: 'bold'
                          }}>
                            {user.userType}
                          </Box>
                        </TableCell>
                        <TableCell>
                          <Box sx={{ 
                            display: 'inline-block', 
                            px: 1, 
                            py: 0.5, 
                            borderRadius: 1,
                            bgcolor: user.isApproved ? 'success.light' : 'warning.light',
                            color: 'white',
                            fontSize: '0.75rem',
                            fontWeight: 'bold'
                          }}>
                            {user.isApproved ? 'APPROVED' : 'PENDING'}
                          </Box>
                        </TableCell>
                        <TableCell>
                          {user.registrationDate ? new Date(user.registrationDate).toLocaleDateString() : 'N/A'}
                        </TableCell>
                        <TableCell>
                          {!user.isApproved && (
                            <Button 
                              variant="outlined"
                              size="small"
                              onClick={() => approveUser(user.id)}
                            >
                              Approve
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Paper>
          </Grid>
        </Grid>
      )}

      {tabValue === 1 && (
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Paper sx={{ p: 3 }}>
              <Typography variant="h5" gutterBottom>
                Report Generation
              </Typography>
              <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                <Button
                  variant="outlined"
                  startIcon={<Report />}
                  onClick={() => {
                    setReportType('WEEKLY');
                    generateReport();
                  }}
                >
                  Generate Weekly Report
                </Button>
                <Button
                  variant="outlined"
                  startIcon={<Report />}
                  onClick={() => {
                    setReportType('MONTHLY');
                    generateReport();
                  }}
                >
                  Generate Monthly Report
                </Button>
                <Button
                  variant="outlined"
                  startIcon={<Report />}
                  onClick={() => {
                    setReportType('YEARLY');
                    generateReport();
                  }}
                >
                  Generate Yearly Report
                </Button>
              </Box>
            </Paper>
          </Grid>
        </Grid>
      )}
    </Container>
  );
};

export default AdminDashboard;