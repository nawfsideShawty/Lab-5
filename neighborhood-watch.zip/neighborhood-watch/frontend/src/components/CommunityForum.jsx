// src/components/CommunityForum.jsx
import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Box,
  Card,
  CardContent,
  CardActions,
  Avatar,
  Divider,
  Alert,
  CircularProgress
} from '@mui/material';
import { Send, Comment, Person } from '@mui/icons-material';
const token = localStorage.getItem('token');
const response = await fetch('http://localhost:8080/api/community/posts', {
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  }
})
const CommunityForum = () => {
  const [posts, setPosts] = useState([]);
  const [newPost, setNewPost] = useState({ title: '', content: '' });
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchCommunityPosts();
  }, []);

  const fetchCommunityPosts = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8080/api/community/posts', {
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log('📝 Fetched posts:', data);
        setPosts(data);
      } else {
        throw new Error('Failed to fetch posts');
      }
    } catch (error) {
      console.error('Failed to fetch posts:', error);
      setError('Failed to load community posts');
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePost = async () => {
    if (!newPost.title.trim() || !newPost.content.trim()) {
      setError('Please fill in both title and content');
      return;
    }

    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8080/api/community/posts', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          title: newPost.title,
          content: newPost.content
        })
      });

      if (response.ok) {
        setNewPost({ title: '', content: '' });
        setSuccess('Post created successfully!');
        setError('');
        // Refresh the posts list
        await fetchCommunityPosts();
      } else {
        throw new Error('Failed to create post');
      }
    } catch (error) {
      console.error('Failed to create post:', error);
      setError('Failed to create post. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleAddComment = async (postId, commentText) => {
    if (!commentText.trim()) return;

    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:8080/api/community/posts/${postId}/comments`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
          comment: commentText 
        })
      });

      if (response.ok) {
        setNewComment('');
        setSuccess('Comment added successfully!');
        // Refresh the posts to show the new comment
        await fetchCommunityPosts();
      } else {
        throw new Error('Failed to add comment');
      }
    } catch (error) {
      console.error('Failed to add comment:', error);
      setError('Failed to add comment. Please try again.');
    }
  };

  const getInitials = (firstName, lastName) => {
    return `${firstName?.[0] || ''}${lastName?.[0] || ''}`.toUpperCase();
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString();
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>
        Community Forum
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>
          {error}
        </Alert>
      )}

      {success && (
        <Alert severity="success" sx={{ mb: 2 }} onClose={() => setSuccess('')}>
          {success}
        </Alert>
      )}

      {/* Create New Post */}
      <Paper sx={{ p: 3, mb: 4 }}>
        <Typography variant="h6" gutterBottom>
          Create New Post
        </Typography>
        <TextField
          fullWidth
          label="Post Title"
          value={newPost.title}
          onChange={(e) => setNewPost({...newPost, title: e.target.value})}
          sx={{ mb: 2 }}
          placeholder="What would you like to discuss?"
        />
        <TextField
          fullWidth
          label="Post Content"
          multiline
          rows={3}
          value={newPost.content}
          onChange={(e) => setNewPost({...newPost, content: e.target.value})}
          sx={{ mb: 2 }}
          placeholder="Share your thoughts with the community..."
        />
        <Button 
          variant="contained" 
          onClick={handleCreatePost}
          disabled={!newPost.title.trim() || !newPost.content.trim() || loading}
          startIcon={loading ? <CircularProgress size={20} /> : <Send />}
        >
          {loading ? 'Posting...' : 'Post to Community'}
        </Button>
      </Paper>

      {/* Posts List */}
      {loading && posts.length === 0 ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
          <CircularProgress />
        </Box>
      ) : posts.length === 0 ? (
        <Paper sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h6" color="text.secondary" gutterBottom>
            No posts yet
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Be the first to start a discussion in the community!
          </Typography>
        </Paper>
      ) : (
        posts.map((post) => (
          <Card key={post.id} sx={{ mb: 3 }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Avatar sx={{ mr: 2, bgcolor: 'primary.main' }}>
                  {post.member ? getInitials(post.member.firstName, post.member.lastName) : <Person />}
                </Avatar>
                <Box sx={{ flexGrow: 1 }}>
                  <Typography variant="h6" component="div">
                    {post.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    By {post.member ? `${post.member.firstName} ${post.member.lastName}` : 'Unknown User'} • {formatDate(post.createdAt || post.postDate)}
                  </Typography>
                </Box>
              </Box>
              
              <Typography variant="body1" paragraph sx={{ whiteSpace: 'pre-wrap' }}>
                {post.content}
              </Typography>
              
              {/* Comments Section */}
              <Divider sx={{ my: 2 }} />
              
              <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
                <Comment sx={{ mr: 1, fontSize: 20 }} />
                Comments ({post.comments ? post.comments.length : 0})
              </Typography>
              
              {/* Display Comments */}
              {post.comments && post.comments.map((comment) => (
                <Box key={comment.id} sx={{ display: 'flex', mb: 2, ml: 2 }}>
                  <Avatar 
                    sx={{ 
                      mr: 2, 
                      width: 32, 
                      height: 32, 
                      bgcolor: 'secondary.main',
                      fontSize: '0.8rem'
                    }}
                  >
                    {comment.member ? getInitials(comment.member.firstName, comment.member.lastName) : 'U'}
                  </Avatar>
                  <Box sx={{ flexGrow: 1 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
                      <Typography variant="subtitle2" sx={{ mr: 1 }}>
                        {comment.member ? `${comment.member.firstName} ${comment.member.lastName}` : 'Unknown User'}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {formatDate(comment.createdAt || comment.commentDate)}
                      </Typography>
                    </Box>
                    <Typography variant="body2" sx={{ bgcolor: 'grey.50', p: 1, borderRadius: 1 }}>
                      {comment.content || comment.comment}
                    </Typography>
                  </Box>
                </Box>
              ))}

              {/* Add Comment Input */}
              <CardActions sx={{ p: 0, pt: 2 }}>
                <TextField
                  size="small"
                  fullWidth
                  placeholder="Add a comment..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  sx={{ mr: 1 }}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleAddComment(post.id, newComment);
                    }
                  }}
                />
                <Button 
                  size="small" 
                  startIcon={<Send />}
                  onClick={() => handleAddComment(post.id, newComment)}
                  disabled={!newComment.trim()}
                  variant="outlined"
                >
                  Comment
                </Button>
              </CardActions>
            </CardContent>
          </Card>
        ))
      )}
    </Container>
  );
};

export default CommunityForum;