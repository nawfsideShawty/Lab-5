import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Paper,
  Typography,
  Card,
  CardContent,
  Box,
  Button
} from '@mui/material';
import {
  Security,
  Warning,
  Forum,
  Payment,
  QrCode
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const MemberDashboard = () => {
  const [stats, setStats] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    fetchMemberStats();
  }, []);

  const fetchMemberStats = async () => {
    const token = localStorage.getItem('token');
    try {
      const response = await fetch('http://localhost:8080/api/member/stats', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    }
  };

  const QuickActionCard = ({ icon, title, description, buttonText, onClick, color = 'primary' }) => (
    <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <CardContent sx={{ flexGrow: 1, textAlign: 'center' }}>
        <Box sx={{ color: `${color}.main`, mb: 2 }}>
          {icon}
        </Box>
        <Typography variant="h6" gutterBottom>
          {title}
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          {description}
        </Typography>
        <Button variant="contained" color={color} onClick={onClick} fullWidth>
          {buttonText}
        </Button>
      </CardContent>
    </Card>
  );

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>
        Member Dashboard
      </Typography>
      
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="primary">
              {stats.patrolsThisWeek || 0}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Patrols This Week
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="success.main">
              {stats.complianceRate || 0}%
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Compliance Rate
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="warning.main">
              {stats.activeAlerts || 0}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Active Alerts
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={3}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color={stats.subscriptionActive ? 'success.main' : 'error.main'}>
              {stats.subscriptionActive ? 'Active' : 'Inactive'}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Subscription
            </Typography>
          </Paper>
        </Grid>
      </Grid>

      <Typography variant="h5" gutterBottom sx={{ mb: 3 }}>
        Quick Actions
      </Typography>
      
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6} md={3}>
          <QuickActionCard
            icon={<Security fontSize="large" />}
            title="Patrol Stats"
            description="View security patrol statistics and compliance reports"
            buttonText="View Stats"
            onClick={() => navigate('/stats')}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <QuickActionCard
            icon={<Warning fontSize="large" />}
            title="Emergency"
            description="Raise emergency alert for immediate assistance"
            buttonText="Emergency"
            onClick={() => navigate('/emergency')}
            color="error"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <QuickActionCard
            icon={<Forum fontSize="large" />}
            title="Community"
            description="Join community discussions and posts"
            buttonText="Community"
            onClick={() => navigate('/community')}
            color="secondary"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <QuickActionCard
            icon={<Payment fontSize="large" />}
            title="Payment"
            description="Manage your subscription payments"
            buttonText="Pay Now"
            onClick={() => navigate('/payment')}
            color="success"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <QuickActionCard
            icon={<QrCode fontSize="large" />}
            title="My QR Code"
            description="Get your house QR code for security patrols"
            buttonText="Get QR Code"
            onClick={() => navigate('/my-qr-code')}
            color="info"
          />
        </Grid>
      </Grid>
    </Container>
  );
};

export default MemberDashboard;