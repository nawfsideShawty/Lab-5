// src/components/ForumCategories.js
import React from 'react';

const CATEGORIES = [
  { id: 'all', name: 'All Posts', icon: '📋' },
  { id: 'general', name: 'General Discussion', icon: '💬' },
  { id: 'safety', name: 'Safety Alerts', icon: '🚨' },
  { id: 'events', name: 'Local Events', icon: '🎉' },
  { id: 'help', name: 'Help & Support', icon: '🤝' },
  { id: 'news', name: 'Neighborhood News', icon: '📰' }
];

const ForumCategories = ({ activeCategory, onCategoryChange }) => {
  return (
    <div className="forum-categories">
      <h3>Categories</h3>
      <div className="categories-list">
        {CATEGORIES.map(category => (
          <button
            key={category.id}
            className={`category-btn ${activeCategory === category.id ? 'active' : ''}`}
            onClick={() => onCategoryChange(category.id)}
          >
            <span className="category-icon">{category.icon}</span>
            <span className="category-name">{category.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default ForumCategories;