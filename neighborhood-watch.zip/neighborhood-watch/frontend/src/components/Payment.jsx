// src/components/Payment.jsx
import React, { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import {
  Container,
  Paper,
  Typography,
  Button,
  Box,
  Alert,
  CircularProgress,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow
} from '@mui/material';

const stripePromise = loadStripe('pk_test_your_publishable_key_here');

const PaymentForm = ({ onPaymentSuccess }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('CREDIT_CARD');
  const [monthlyFee, setMonthlyFee] = useState(50);

  useEffect(() => {
    fetchSubscriptionFee();
  }, []);

  const fetchSubscriptionFee = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8080/api/payments/subscription-fee', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setMonthlyFee(data.monthlyFee || 50);
      }
    } catch (error) {
      console.error('Failed to fetch subscription fee:', error);
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError('');

    try {
      const token = localStorage.getItem('token');
      
      // Create payment intent
      const response = await fetch('http://localhost:8080/api/payments/create-payment-intent', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          paymentMethod: paymentMethod,
          amount: monthlyFee
        })
      });

      if (!response.ok) {
        throw new Error('Failed to create payment intent');
      }

      const paymentData = await response.json();
      
      if (paymentMethod === 'CREDIT_CARD') {
        const cardElement = elements.getElement(CardElement);
        
        const result = await stripe.confirmCardPayment(paymentData.clientSecret, {
          payment_method: {
            card: cardElement,
          }
        });

        if (result.error) {
          setError(result.error.message);
        } else {
          await handlePaymentSuccess(paymentData.transactionId || result.paymentIntent.id);
        }
      } else {
        // For other payment methods
        await handlePaymentSuccess(paymentData.transactionId);
      }
    } catch (err) {
      setError('Payment processing failed. Please try again.');
      console.error('Payment error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handlePaymentSuccess = async (transactionId) => {
    try {
      const token = localStorage.getItem('token');
      await fetch('http://localhost:8080/api/payments/record-payment', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          transactionId: transactionId,
          status: 'COMPLETED'
        })
      });
      
      onPaymentSuccess();
    } catch (error) {
      console.error('Failed to record payment:', error);
    }
  };

  return (
    <Paper sx={{ p: 4, maxWidth: 500, margin: 'auto' }}>
      <Typography variant="h5" gutterBottom>
        Monthly Subscription Payment
      </Typography>
      <Typography variant="h6" color="primary" gutterBottom>
        Amount: {monthlyFee} Pula
      </Typography>
      
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      
      <form onSubmit={handleSubmit}>
        <FormControl fullWidth sx={{ mb: 3 }}>
          <InputLabel>Payment Method</InputLabel>
          <Select
            value={paymentMethod}
            onChange={(e) => setPaymentMethod(e.target.value)}
            label="Payment Method"
          >
            <MenuItem value="CREDIT_CARD">Credit Card</MenuItem>
            <MenuItem value="MOBILE_CARD">Mobile Card</MenuItem>
            <MenuItem value="BANK_TRANSFER">Bank Transfer</MenuItem>
          </Select>
        </FormControl>
        
        {paymentMethod === 'CREDIT_CARD' && (
          <Box sx={{ mb: 3 }}>
            <Typography variant="subtitle1" gutterBottom>
              Card Details
            </Typography>
            <CardElement
              options={{
                style: {
                  base: {
                    fontSize: '16px',
                    color: '#424770',
                    '::placeholder': {
                      color: '#aab7c4',
                    },
                  },
                },
              }}
            />
          </Box>
        )}
        
        {paymentMethod === 'MOBILE_CARD' && (
          <Alert severity="info" sx={{ mb: 2 }}>
            Please use your mobile banking app to complete the payment.
          </Alert>
        )}
        
        {paymentMethod === 'BANK_TRANSFER' && (
          <Alert severity="info" sx={{ mb: 2 }}>
            Bank transfer details will be provided after payment initiation.
          </Alert>
        )}
        
        <Button
          type="submit"
          disabled={!stripe || loading}
          variant="contained"
          fullWidth
          size="large"
        >
          {loading ? <CircularProgress size={24} /> : `Pay ${monthlyFee} Pula`}
        </Button>
      </form>
    </Paper>
  );
};

const Payment = () => {
  const [paymentCompleted, setPaymentCompleted] = useState(false);
  const [subscriptionStatus, setSubscriptionStatus] = useState(null);
  const [paymentHistory, setPaymentHistory] = useState([]);

  useEffect(() => {
    checkSubscriptionStatus();
    fetchPaymentHistory();
  }, []);

  const checkSubscriptionStatus = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8080/api/payments/subscription-status', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setSubscriptionStatus(data);
      }
    } catch (error) {
      console.error('Failed to check subscription status:', error);
    }
  };

  const fetchPaymentHistory = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8080/api/payments/history', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setPaymentHistory(data);
      }
    } catch (error) {
      console.error('Failed to fetch payment history:', error);
    }
  };

  const handlePaymentSuccess = () => {
    setPaymentCompleted(true);
    setSubscriptionStatus({ status: 'ACTIVE' });
    fetchPaymentHistory();
  };

  if (subscriptionStatus?.status === 'ACTIVE') {
    return (
      <Container maxWidth="lg" sx={{ mt: 4 }}>
        <Alert severity="success" sx={{ mb: 3 }}>
          Your subscription is active! Next payment due in 30 days.
        </Alert>
        
        <Typography variant="h5" gutterBottom>
          Payment History
        </Typography>
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Date</TableCell>
                <TableCell>Amount</TableCell>
                <TableCell>Method</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Transaction ID</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paymentHistory.map((payment) => (
                <TableRow key={payment.id}>
                  <TableCell>{new Date(payment.paymentDate).toLocaleDateString()}</TableCell>
                  <TableCell>{payment.amount} Pula</TableCell>
                  <TableCell>{payment.paymentMethod}</TableCell>
                  <TableCell>{payment.status}</TableCell>
                  <TableCell>{payment.transactionId}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Container>
    );
  }

  if (subscriptionStatus?.status === 'SUSPENDED') {
    return (
      <Container maxWidth="sm" sx={{ mt: 4 }}>
        <Alert severity="warning" sx={{ mb: 3 }}>
          Your subscription is suspended due to non-payment. Please make a payment to reactivate.
        </Alert>
        <Elements stripe={stripePromise}>
          <PaymentForm onPaymentSuccess={handlePaymentSuccess} />
        </Elements>
      </Container>
    );
  }

  if (paymentCompleted) {
    return (
      <Container maxWidth="sm" sx={{ mt: 4 }}>
        <Alert severity="success">
          Payment completed successfully! Your subscription is now active.
        </Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="sm" sx={{ mt: 4 }}>
      <Elements stripe={stripePromise}>
        <PaymentForm onPaymentSuccess={handlePaymentSuccess} />
      </Elements>
    </Container>
  );
};

export default Payment;