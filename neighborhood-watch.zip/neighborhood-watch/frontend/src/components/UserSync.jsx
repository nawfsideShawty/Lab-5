// src/components/UserSync.jsx
import { useEffect, useState } from 'react';
import { Snackbar, Alert, CircularProgress, Box } from '@mui/material';

const UserSync = ({ user, keycloak }) => {
  const [synced, setSynced] = useState(false);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'info' });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const syncUserWithBackend = async () => {
      if (!user || !keycloak.token || synced || loading) return;

      setLoading(true);
      
      try {
        console.log('🔄 Starting user sync...', user);
        
        const response = await fetch('http://localhost:8080/api/auth/sync-user', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${keycloak.token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            keycloakId: user.keycloakId,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            username: user.username,
            roles: user.roles
          })
        });

        console.log('📡 Sync response status:', response.status);

        if (response.ok) {
          const result = await response.json();
          setSynced(true);
          console.log('✅ User sync successful:', result);
          
          if (result.isNewUser) {
            setNotification({
              open: true,
              message: 'Welcome to Neighborhood Watch! Your account has been created.',
              severity: 'success'
            });
          } else {
            setNotification({
              open: true,
              message: `Welcome back, ${user.firstName}!`,
              severity: 'success'
            });
          }
        } else if (response.status === 401) {
          // Token refresh needed
          console.log('🔄 Token expired, refreshing...');
          try {
            const refreshed = await keycloak.updateToken(30);
            if (refreshed) {
              localStorage.setItem('token', keycloak.token);
              console.log('✅ Token refreshed, retrying sync...');
              // Retry sync with new token
              syncUserWithBackend();
            } else {
              throw new Error('Token refresh failed');
            }
          } catch (refreshError) {
            console.error('❌ Token refresh failed:', refreshError);
            setNotification({
              open: true,
              message: 'Session expired. Please refresh the page.',
              severity: 'warning'
            });
          }
        } else if (response.status === 404) {
          // Sync endpoint doesn't exist yet - this is normal during development
          console.log('ℹ️ Sync endpoint not implemented yet');
          setSynced(true); // Mark as synced to avoid retries
          setNotification({
            open: true,
            message: `Welcome ${user.firstName}!`,
            severity: 'info'
          });
        } else {
          // Other error
          const errorText = await response.text();
          console.error('❌ Sync failed with status:', response.status, errorText);
          throw new Error(`Sync failed: ${response.status}`);
        }
      } catch (error) {
        console.error('💥 Failed to sync user with backend:', error);
        
        // Don't show error for 404 - it's expected if endpoint isn't implemented
        if (!error.message.includes('404')) {
          setNotification({
            open: true,
            message: 'Welcome! Some features may be limited.',
            severity: 'warning'
          });
        }
        
        setSynced(true); // Mark as synced to avoid infinite retries
      } finally {
        setLoading(false);
      }
    };

    syncUserWithBackend();
  }, [user, keycloak, synced, loading]);

  const handleCloseNotification = () => {
    setNotification({ ...notification, open: false });
  };

  // Show loading indicator during sync
  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', p: 2 }}>
        <CircularProgress size={20} sx={{ mr: 2 }} />
        <span>Syncing user data...</span>
      </Box>
    );
  }

  return (
    <Snackbar 
      open={notification.open} 
      autoHideDuration={6000} 
      onClose={handleCloseNotification}
      anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
    >
      <Alert onClose={handleCloseNotification} severity={notification.severity}>
        {notification.message}
      </Alert>
    </Snackbar>
  );
};

export default UserSync;