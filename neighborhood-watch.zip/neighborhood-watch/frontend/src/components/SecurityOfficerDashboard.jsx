import React, { useState, useEffect } from 'react';
import {
  Container,
  Grid,
  Paper,
  Typography,
  Card,
  CardContent,
  Box,
  Button,
  LinearProgress
} from '@mui/material';
import {
  QrCodeScanner,
  History,
  Assignment
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

const SecurityOfficerDashboard = () => {
  const [officerStats, setOfficerStats] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    fetchOfficerStats();
  }, []);

  const fetchOfficerStats = async () => {
    const token = localStorage.getItem('token');
    try {
      const response = await fetch('http://localhost:8080/api/officer/stats', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      setOfficerStats(data);
    } catch (error) {
      console.error('Failed to fetch officer stats:', error);
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" gutterBottom>
        Security Officer Dashboard
      </Typography>
      
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="primary">
              {officerStats.todayScans || 0}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Scans Today
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color="success.main">
              {officerStats.weeklyScans || 0}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Weekly Scans
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="h4" color={officerStats.complianceRate >= 80 ? 'success.main' : 'warning.main'}>
              {officerStats.complianceRate || 0}%
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Compliance Rate
            </Typography>
          </Paper>
        </Grid>
      </Grid>

      {/* Compliance Progress */}
      <Paper sx={{ p: 3, mb: 4 }}>
        <Typography variant="h6" gutterBottom>
          Weekly Compliance Progress
        </Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <Typography variant="body2" sx={{ minWidth: 100 }}>
            Target: 80%
          </Typography>
          <LinearProgress 
            variant="determinate" 
            value={officerStats.complianceRate || 0}
            color={officerStats.complianceRate >= 80 ? 'success' : 'warning'}
            sx={{ flexGrow: 1, height: 10, borderRadius: 5 }}
          />
          <Typography variant="body2" sx={{ minWidth: 60, textAlign: 'right' }}>
            {officerStats.complianceRate || 0}%
          </Typography>
        </Box>
      </Paper>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Card sx={{ cursor: 'pointer' }} onClick={() => navigate('/patrol-scans')}>
            <CardContent sx={{ textAlign: 'center', p: 4 }}>
              <QrCodeScanner sx={{ fontSize: 60, color: 'primary.main', mb: 2 }} />
              <Typography variant="h6" gutterBottom>
                Start Patrol Scan
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Scan QR codes during your patrol route
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={6}>
          <Card sx={{ cursor: 'pointer' }} onClick={() => navigate('/patrol-scans')}>
            <CardContent sx={{ textAlign: 'center', p: 4 }}>
              <History sx={{ fontSize: 60, color: 'secondary.main', mb: 2 }} />
              <Typography variant="h6" gutterBottom>
                Scan History
              </Typography>
              <Typography variant="body2" color="text.secondary">
                View your previous patrol scans and history
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
};

export default SecurityOfficerDashboard;