// src/components/QRScanner.jsx
import React, { useEffect, useState } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { 
  Dialog, 
  DialogTitle, 
  DialogContent, 
  DialogActions, 
  Button,
  Box,
  Typography,
  Alert,
  CircularProgress
} from '@mui/material';
import { QrCodeScanner, CheckCircle, Error } from '@mui/icons-material';

const QRScanner = ({ open, onClose, onScanSuccess }) => {
  const [scanResult, setScanResult] = useState(null);
  const [error, setError] = useState(null);
  const [scanner, setScanner] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      initializeScanner();
    } else {
      cleanupScanner();
    }

    return () => {
      cleanupScanner();
    };
  }, [open]);

  const initializeScanner = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Small delay to ensure DOM is ready
      await new Promise(resolve => setTimeout(resolve, 100));
      
      const html5QrcodeScanner = new Html5QrcodeScanner(
        "qr-reader",
        { 
          fps: 10,
          qrbox: { width: 250, height: 250 },
          aspectRatio: 1.0,
        },
        false
      );

      html5QrcodeScanner.render(
        (decodedText, decodedResult) => {
          handleScanSuccess(decodedText, decodedResult);
        },
        (errorMessage) => {
          // Ignore "No MultiFormat Readers" error - it's normal when no QR code is detected
          if (!errorMessage.includes('No MultiFormat Readers')) {
            console.log('Scan error:', errorMessage);
          }
        }
      );

      setScanner(html5QrcodeScanner);
      setLoading(false);
      
    } catch (err) {
      console.error('Failed to initialize scanner:', err);
      setError('Failed to initialize camera. Please check permissions.');
      setLoading(false);
    }
  };

  const cleanupScanner = () => {
    if (scanner) {
      try {
        scanner.clear().catch(error => {
          console.log("Scanner cleanup warning:", error);
        });
      } catch (err) {
        console.log("Scanner cleanup error:", err);
      }
      setScanner(null);
    }
    setScanResult(null);
    setError(null);
  };

  const handleScanSuccess = async (decodedText, decodedResult) => {
    setScanResult({
      text: decodedText,
      result: decodedResult
    });
    
    try {
      const token = localStorage.getItem('token');
      const scanData = {
        qrContent: decodedText,
        scanTime: new Date().toISOString(),
        latitude: null, // You can get from GPS if available
        longitude: null
      };
      
      await fetch('http://localhost:8080/api/officer/scan', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(scanData)
      });
      
    } catch (error) {
      console.error('Failed to record scan:', error);
    }
    
    // Auto-close after success
    setTimeout(() => {
      if (onScanSuccess) {
        onScanSuccess(decodedText, decodedResult);
      }
      onClose();
    }, 1500);
  };

  const handleManualClose = () => {
    cleanupScanner();
    onClose();
  };

  const requestCameraPermission = async () => {
    try {
      setLoading(true);
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      // Close the stream immediately since html5-qrcode will handle it
      stream.getTracks().forEach(track => track.stop());
      setLoading(false);
      initializeScanner();
    } catch (err) {
      setError('Camera access denied. Please allow camera permissions and try again.');
      setLoading(false);
    }
  };

  return (
    <Dialog 
      open={open} 
      onClose={handleManualClose}
      maxWidth="md"
      fullWidth
    >
      <DialogTitle>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <QrCodeScanner sx={{ mr: 1 }} />
          Scan Patrol QR Code
        </Box>
      </DialogTitle>
      
      <DialogContent>
        {error && (
          <Alert 
            severity="error" 
            sx={{ mb: 2 }}
            action={
              error.includes('permissions') && (
                <Button color="inherit" size="small" onClick={requestCameraPermission}>
                  Retry
                </Button>
              )
            }
          >
            {error}
          </Alert>
        )}
        
        {loading && (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
            <CircularProgress />
          </Box>
        )}
        
        {scanResult ? (
          <Box sx={{ textAlign: 'center', py: 4 }}>
            <CheckCircle sx={{ fontSize: 60, color: 'success.main', mb: 2 }} />
            <Typography variant="h6" color="success.main" gutterBottom>
              QR Code Scanned Successfully!
            </Typography>
            <Typography variant="body2" color="text.secondary">
              House ID: {scanResult.text}
            </Typography>
          </Box>
        ) : (
          <Box sx={{ textAlign: 'center' }}>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              Point your camera at the QR code on the gate
            </Typography>
            <div id="qr-reader" style={{ width: '100%', minHeight: '300px' }} />
          </Box>
        )}
      </DialogContent>
      
      <DialogActions>
        <Button onClick={handleManualClose}>
          Cancel
        </Button>
        {error && error.includes('permissions') && (
          <Button onClick={requestCameraPermission} variant="contained">
            Allow Camera
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
};

export default QRScanner;