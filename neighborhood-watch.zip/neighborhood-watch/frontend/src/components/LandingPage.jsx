import React from 'react';
import {
  Container,
  Box,
  Typography,
  Button,
  Grid,
  Paper,
  Card,
  CardContent,
  AppBar,
  Toolbar
} from '@mui/material';
import {
  Security,
  Groups,
  Notifications,
  Payment,
  QrCodeScanner
} from '@mui/icons-material';
import { login, register } from '../keycloak';

const LandingPage = () => {
  const handleLogin = () => {
    login();
  };

  const handleRegister = () => {
    register();
  };

  const FeatureCard = ({ icon, title, description }) => (
    <Card sx={{ height: '100%', transition: 'transform 0.2s', '&:hover': { transform: 'translateY(-4px)' } }}>
      <CardContent sx={{ textAlign: 'center', p: 3 }}>
        <Box sx={{ color: 'primary.main', mb: 2, fontSize: '3rem' }}>
          {icon}
        </Box>
        <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold' }}>
          {title}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {description}
        </Typography>
      </CardContent>
    </Card>
  );

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static" elevation={0}>
        <Toolbar>
          <Security sx={{ mr: 2 }} />
          <Typography variant="h6" component="div" sx={{ flexGrow: 1, fontWeight: 'bold' }}>
            Neighborhood Watch
          </Typography>
          <Button color="inherit" onClick={handleLogin}>
            Login
          </Button>
          <Button color="inherit" onClick={handleRegister} sx={{ ml: 1 }}>
            Register
          </Button>
        </Toolbar>
      </AppBar>

      <Box
        sx={{
          background: 'linear-gradient(135deg, #1976d2 0%, #004ba0 100%)',
          color: 'white',
          py: 8,
          textAlign: 'center'
        }}
      >
        <Container maxWidth="lg">
          <Typography variant="h2" component="h1" gutterBottom sx={{ fontWeight: 'bold', mb: 3 }}>
            Secure Your Community
          </Typography>
          <Typography variant="h5" component="p" sx={{ mb: 4, maxWidth: '600px', mx: 'auto' }}>
            Advanced neighborhood security monitoring with real-time patrol tracking, emergency alerts, and community engagement.
          </Typography>
          <Box sx={{ mt: 4 }}>
            <Button
              variant="contained"
              size="large"
              onClick={handleRegister}
              sx={{
                bgcolor: 'white',
                color: 'primary.main',
                px: 4,
                py: 1.5,
                fontSize: '1.1rem',
                fontWeight: 'bold',
                '&:hover': {
                  bgcolor: 'grey.100'
                }
              }}
            >
              Get Started - Register Now
            </Button>
          </Box>
        </Container>
      </Box>

      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Typography variant="h3" component="h2" textAlign="center" gutterBottom sx={{ fontWeight: 'bold', mb: 6 }}>
          How It Works
        </Typography>
        
        <Grid container spacing={4}>
          <Grid item xs={12} md={4}>
            <FeatureCard
              icon={<Security />}
              title="Security Patrols"
              description="Real-time monitoring of security officer patrols with QR code scanning and compliance tracking."
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <FeatureCard
              icon={<Groups />}
              title="Community Alerts"
              description="Instant emergency alerts and community posts to keep everyone informed and safe."
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <FeatureCard
              icon={<QrCodeScanner />}
              title="QR Code Verification"
              description="Each property has unique QR codes that security officers scan during patrols for verification."
            />
          </Grid>
        </Grid>
      </Container>

      <Box sx={{ bgcolor: 'grey.50', py: 8 }}>
        <Container maxWidth="lg">
          <Typography variant="h3" component="h2" textAlign="center" gutterBottom sx={{ fontWeight: 'bold', mb: 6 }}>
            For Everyone in the Community
          </Typography>
          
          <Grid container spacing={4}>
            <Grid item xs={12} md={4}>
              <Paper sx={{ p: 4, textAlign: 'center', height: '100%' }}>
                <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'primary.main' }}>
                  Residents
                </Typography>
                <Typography variant="body1">
                  Monitor security patrols, receive alerts, engage with community, and manage subscriptions easily.
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} md={4}>
              <Paper sx={{ p: 4, textAlign: 'center', height: '100%' }}>
                <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'secondary.main' }}>
                  Security Officers
                </Typography>
                <Typography variant="body1">
                  Scan QR codes during patrols, track your routes, and ensure community safety with our mobile app.
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} md={4}>
              <Paper sx={{ p: 4, textAlign: 'center', height: '100%' }}>
                <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: 'error.main' }}>
                  Administrators
                </Typography>
                <Typography variant="body1">
                  Manage users, monitor compliance, generate reports, and oversee the entire security system.
                </Typography>
              </Paper>
            </Grid>
          </Grid>
        </Container>
      </Box>

      <Box sx={{ py: 8, textAlign: 'center' }}>
        <Container maxWidth="md">
          <Typography variant="h4" component="h2" gutterBottom sx={{ fontWeight: 'bold' }}>
            Ready to Secure Your Neighborhood?
          </Typography>
          <Typography variant="h6" color="text.secondary" sx={{ mb: 4 }}>
            Join hundreds of residents who trust our system for their community security.
          </Typography>
          <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Button
              variant="contained"
              size="large"
              onClick={handleRegister}
              sx={{ px: 4, py: 1.5, fontSize: '1.1rem' }}
            >
              Register Now
            </Button>
            <Button
              variant="outlined"
              size="large"
              onClick={handleLogin}
              sx={{ px: 4, py: 1.5, fontSize: '1.1rem' }}
            >
              Login
            </Button>
          </Box>
        </Container>
      </Box>

      <Box sx={{ bgcolor: 'primary.main', color: 'white', py: 4, textAlign: 'center' }}>
        <Container maxWidth="lg">
          <Typography variant="body2">
            © 2024 Neighborhood Watch System. All rights reserved.
          </Typography>
        </Container>
      </Box>
    </Box>
  );
};

export default LandingPage;