// src/hooks/usePosts.js
import { useState, useEffect } from 'react';
import { fetchPosts, createPost, updatePost, deletePost } from '../services/postService';
import { createNewPostObject } from '../utils/postUtils';

export const usePosts = (currentMemberId) => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Load all posts
  const loadPosts = async () => {
    setLoading(true);
    setError(null);
    try {
      const postsData = await fetchPosts();
      // Sort by creation date, newest first
      const sortedPosts = postsData.sort((a, b) => 
        new Date(b.createdAt) - new Date(a.createdAt)
      );
      setPosts(sortedPosts);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Add new post
  const addPost = async (title, content) => {
    setError(null);
    try {
      const newPost = createNewPostObject(title, content, currentMemberId);
      const createdPost = await createPost(newPost);
      setPosts(prevPosts => [createdPost, ...prevPosts]);
      return createdPost;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  // Edit existing post
  const editPost = async (postId, updates) => {
    setError(null);
    try {
      const updatedPost = await updatePost(postId, {
        ...updates,
        // Preserve original fields that shouldn't change
        id: postId,
        memberId: posts.find(p => p.id === postId)?.memberId,
        createdAt: posts.find(p => p.id === postId)?.createdAt
      });
      setPosts(prevPosts => 
        prevPosts.map(post => 
          post.id === postId ? updatedPost : post
        )
      );
      return updatedPost;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  // Remove post
  const removePost = async (postId) => {
    setError(null);
    try {
      await deletePost(postId);
      setPosts(prevPosts => prevPosts.filter(post => post.id !== postId));
      return true;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  // Load posts on component mount
  useEffect(() => {
    loadPosts();
  }, []);

  return {
    posts,
    loading,
    error,
    addPost,
    editPost,
    removePost,
    refreshPosts: loadPosts
  };
};